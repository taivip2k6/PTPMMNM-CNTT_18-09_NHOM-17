
<?php
/**
 * BugFlow - User Dashboard
 * Khu vực người dùng, độc lập với giao diện Admin.
 * Dữ liệu hiện tại là dữ liệu mẫu.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$userName = $_SESSION['user']['name']
    ?? $_SESSION['user_name']
    ?? 'Duy Khánh';

function bfDashboardEscape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Dữ liệu mẫu: thay bằng dữ liệu MySQL sau.
$bugs = [
    [
        'id' => 1001,
        'title' => 'Login button not working',
        'project' => 'Website Application',
        'priority' => 'High',
        'status' => 'Open',
        'date' => '25/10/2026'
    ],
    [
        'id' => 1002,
        'title' => 'Profile image upload failed',
        'project' => 'Mobile Application',
        'priority' => 'Medium',
        'status' => 'In Progress',
        'date' => '24/10/2026'
    ],
    [
        'id' => 1003,
        'title' => 'API returns 500 error',
        'project' => 'Backend API',
        'priority' => 'Critical',
        'status' => 'Open',
        'date' => '23/10/2026'
    ],
    [
        'id' => 1004,
        'title' => 'Dashboard layout breaks on mobile',
        'project' => 'Website Application',
        'priority' => 'Low',
        'status' => 'Resolved',
        'date' => '22/10/2026'
    ],
    [
        'id' => 1005,
        'title' => 'Password reset email not received',
        'project' => 'Website Application',
        'priority' => 'High',
        'status' => 'In Progress',
        'date' => '21/10/2026'
    ],
    [
        'id' => 1006,
        'title' => 'Incorrect validation message',
        'project' => 'Mobile Application',
        'priority' => 'Low',
        'status' => 'Closed',
        'date' => '20/10/2026'
    ],
];

$totalBugs = count($bugs);
$openBugs = 0;
$progressBugs = 0;
$resolvedBugs = 0;

foreach ($bugs as $bug) {
    if ($bug['status'] === 'Open') {
        $openBugs++;
    } elseif ($bug['status'] === 'In Progress') {
        $progressBugs++;
    } elseif (in_array($bug['status'], ['Resolved', 'Closed'], true)) {
        $resolvedBugs++;
    }
}

$completionRate = $totalBugs > 0
    ? (int) round($resolvedBugs / $totalBugs * 100)
    : 0;

$recentBugs = array_slice($bugs, 0, 4);

$activities = [
    [
        'icon' => 'fa-plus',
        'type' => 'purple',
        'title' => 'Báo cáo lỗi mới',
        'description' => 'Login button not working',
        'time' => '2 giờ trước'
    ],
    [
        'icon' => 'fa-rotate',
        'type' => 'orange',
        'title' => 'Cập nhật trạng thái',
        'description' => 'Profile image upload failed',
        'time' => '5 giờ trước'
    ],
    [
        'icon' => 'fa-check',
        'type' => 'green',
        'title' => 'Lỗi đã được xử lý',
        'description' => 'Dashboard layout breaks on mobile',
        'time' => 'Hôm qua'
    ],
];

function bfDashboardPriorityClass($priority): string
{
    return match ($priority) {
        'Low' => 'bf-priority-low',
        'Medium' => 'bf-priority-medium',
        'High' => 'bf-priority-high',
        'Critical' => 'bf-priority-critical',
        default => '',
    };
}

function bfDashboardStatusClass($status): string
{
    return match ($status) {
        'Open' => 'bf-status-open',
        'In Progress' => 'bf-status-progress',
        'Resolved' => 'bf-status-resolved',
        'Closed' => 'bf-status-closed',
        default => '',
    };
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Không gian của tôi | BugFlow</title>

    <!-- CSS riêng của User -->
    <link rel="stylesheet" href="/assets/css/user.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


</head>

<body>

<div class="bf-user-page">

    <!-- TOPBAR -->
    <header class="bf-user-topbar">

        <div class="bf-user-topbar-label">
            Không gian cá nhân / Tổng quan
        </div>

        <div class="bf-user-topbar-actions">

            <a href="/?page=notifications"
               class="bf-user-icon-button"
               aria-label="Xem thông báo"
               title="Thông báo">
                <i class="fa-regular fa-bell"></i>
            </a>

            <a href="/?page=profile"
               class="bf-user-topbar-avatar"
               aria-label="Hồ sơ cá nhân">
                <?= bfDashboardEscape(
                    function_exists('mb_substr')
                        ? mb_strtoupper(mb_substr($userName, 0, 1, 'UTF-8'), 'UTF-8')
                        : strtoupper(substr($userName, 0, 1))
                ) ?>
            </a>

        </div>
    </header>

    <!-- SIDEBAR DÙNG CHUNG CỦA USER -->
    <?php require __DIR__ . '/sidebar.php'; ?>

    <!-- MAIN CONTENT -->
    <main class="bf-user-content">

        <!-- WELCOME -->
        <section class="bf-user-welcome">

            <div>
                <p class="bf-user-eyebrow">KHÔNG GIAN CỦA TÔI</p>

                <h1>
                    Xin chào, <?= bfDashboardEscape($userName) ?>!
                </h1>

                <p>
                    Theo dõi các báo cáo lỗi và cập nhật mới nhất
                    của bạn tại đây.
                </p>
            </div>

            <a href="/?page=create"
               class="bf-user-primary-button">
                <i class="fa-solid fa-plus"></i>
                Gửi báo lỗi mới
            </a>

        </section>

        <!-- STATISTICS -->
        <section class="bf-user-stats" aria-label="Tổng quan báo cáo">

            <article class="bf-user-stat-card">
                <div class="bf-user-stat-top">
                    <span class="bf-user-stat-label">Tổng báo cáo</span>
                    <span class="bf-user-stat-icon bf-stat-purple">
                        <i class="fa-solid fa-bug"></i>
                    </span>
                </div>
                <div class="bf-user-stat-number"><?= $totalBugs ?></div>
                <div class="bf-user-stat-note">Tất cả lỗi bạn đã gửi</div>
            </article>

            <article class="bf-user-stat-card">
                <div class="bf-user-stat-top">
                    <span class="bf-user-stat-label">Đang chờ xử lý</span>
                    <span class="bf-user-stat-icon bf-stat-red">
                        <i class="fa-solid fa-clock"></i>
                    </span>
                </div>
                <div class="bf-user-stat-number"><?= $openBugs ?></div>
                <div class="bf-user-stat-note">Chưa được xử lý</div>
            </article>

            <article class="bf-user-stat-card">
                <div class="bf-user-stat-top">
                    <span class="bf-user-stat-label">Đang xử lý</span>
                    <span class="bf-user-stat-icon bf-stat-orange">
                        <i class="fa-solid fa-arrows-rotate"></i>
                    </span>
                </div>
                <div class="bf-user-stat-number"><?= $progressBugs ?></div>
                <div class="bf-user-stat-note">Đội ngũ đang khắc phục</div>
            </article>

            <article class="bf-user-stat-card">
                <div class="bf-user-stat-top">
                    <span class="bf-user-stat-label">Đã hoàn thành</span>
                    <span class="bf-user-stat-icon bf-stat-green">
                        <i class="fa-solid fa-check"></i>
                    </span>
                </div>
                <div class="bf-user-stat-number"><?= $resolvedBugs ?></div>
                <div class="bf-user-stat-note">Đã xử lý hoặc đóng</div>
            </article>

        </section>

        <!-- PROGRESS -->
        <section class="bf-user-main-grid">

            <article class="bf-user-card">

                <div class="bf-user-card-header">
                    <div>
                        <h2>Tiến độ xử lý báo cáo</h2>
                        <p>Tình trạng các lỗi bạn đã gửi</p>
                    </div>
                </div>

                <div class="bf-user-progress-layout">

                    <div class="bf-user-progress-circle"
                         style="--bf-progress: <?= $completionRate ?>">

                        <div class="bf-user-progress-inner">
                            <strong><?= $completionRate ?>%</strong>
                            <span>Hoàn thành</span>
                        </div>

                    </div>

                    <div class="bf-user-progress-details">

                        <div class="bf-user-progress-row">
                            <span class="bf-user-dot bf-dot-open"></span>
                            <span>Đang chờ xử lý</span>
                            <strong><?= $openBugs ?></strong>
                        </div>

                        <div class="bf-user-progress-row">
                            <span class="bf-user-dot bf-dot-progress"></span>
                            <span>Đang xử lý</span>
                            <strong><?= $progressBugs ?></strong>
                        </div>

                        <div class="bf-user-progress-row">
                            <span class="bf-user-dot bf-dot-resolved"></span>
                            <span>Đã hoàn thành</span>
                            <strong><?= $resolvedBugs ?></strong>
                        </div>

                    </div>

                </div>

            </article>

            <!-- RECENT ACTIVITY -->
            <article class="bf-user-card">

                <div class="bf-user-card-header">
                    <div>
                        <h2>Hoạt động gần đây</h2>
                        <p>Các cập nhật trong không gian của bạn</p>
                    </div>
                    <a href="/?page=notifications"
                       class="bf-user-text-link">
                        Xem thêm
                    </a>
                </div>

                <div class="bf-user-activity-list">

                    <?php foreach ($activities as $activity): ?>
                        <div class="bf-user-activity-item">

                            <div class="bf-user-activity-icon
                                <?= $activity['type'] === 'purple'
                                    ? 'bf-activity-purple'
                                    : ($activity['type'] === 'orange'
                                        ? 'bf-activity-orange'
                                        : 'bf-activity-green') ?>">

                                <i class="fa-solid
                                    <?= bfDashboardEscape($activity['icon']) ?>"></i>
                            </div>

                            <div class="bf-user-activity-body">
                                <strong>
                                    <?= bfDashboardEscape($activity['title']) ?>
                                </strong>

                                <p>
                                    <?= bfDashboardEscape($activity['description']) ?>
                                </p>
                            </div>

                            <span class="bf-user-activity-time">
                                <?= bfDashboardEscape($activity['time']) ?>
                            </span>

                        </div>
                    <?php endforeach; ?>

                </div>

            </article>

        </section>

        <!-- RECENT BUGS -->
        <section class="bf-user-card">

            <div class="bf-user-card-header">
                <div>
                    <h2>Báo cáo gần đây</h2>
                    <p>Những lỗi bạn đã gửi gần nhất</p>
                </div>

                <a href="/?page=bugs"
                   class="bf-user-text-link">
                    Xem tất cả
                    <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>

            <div class="bf-user-table-wrap">

                <table class="bf-user-table">

                    <thead>
                        <tr>
                            <th>MÃ LỖI</th>
                            <th>THÔNG TIN BÁO CÁO</th>
                            <th>ƯU TIÊN</th>
                            <th>TRẠNG THÁI</th>
                            <th>NGÀY GỬI</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($recentBugs as $bug): ?>
                        <tr>

                            <td>
                                <span class="bf-user-bug-id">
                                    #<?= bfDashboardEscape($bug['id']) ?>
                                </span>
                            </td>

                            <td>
                                <div class="bf-user-bug-title">
                                    <?= bfDashboardEscape($bug['title']) ?>
                                </div>

                                <div class="bf-user-bug-project">
                                    <?= bfDashboardEscape($bug['project']) ?>
                                </div>
                            </td>

                            <td>
                                <span class="bf-user-badge
                                    <?= bfDashboardPriorityClass($bug['priority']) ?>">
                                    <?= bfDashboardEscape($bug['priority']) ?>
                                </span>
                            </td>

                            <td>
                                <span class="bf-user-badge
                                    <?= bfDashboardStatusClass($bug['status']) ?>">
                                    <?= bfDashboardEscape($bug['status']) ?>
                                </span>
                            </td>

                            <td>
                                <?= bfDashboardEscape($bug['date']) ?>
                            </td>

                        </tr>
                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        </section>

        <footer class="bf-user-footer">
            BugFlow · Không gian theo dõi báo cáo cá nhân
        </footer>

    </main>

</div>

</body>
</html>


<?php
/**
 * BugFlow - User Sidebar
 * File: app/views/layouts/user_sidebar.php
 */

$currentPage = $_GET['page'] ?? 'user-dashboard';

/**
 * Kiểm tra menu hiện tại.
 */
if (!function_exists('userSidebarActive')) {
    function userSidebarActive($pages, $currentPage)
    {
        if (!is_array($pages)) {
            $pages = [$pages];
        }

        return in_array($currentPage, $pages, true)
            ? 'active'
            : '';
    }
}

/**
 * Tạo đường dẫn đến trang trong ứng dụng.
 * Hỗ trợ chạy trong thư mục public hoặc thư mục con.
 */
if (!function_exists('userSidebarUrl')) {
    function userSidebarUrl($page)
    {
        $scriptName = $_SERVER['SCRIPT_NAME'] ?? '/index.php';
        $basePath = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');

        if ($basePath === '.' || $basePath === '/') {
            $basePath = '';
        }

        return $basePath . '/?page=' . rawurlencode($page);
    }
}
?>

<style>
    .user-sidebar {
        width: 250px;
        min-width: 250px;
        min-height: 100vh;
        background: #29245f;
        color: #fff;
        display: flex;
        flex-direction: column;
        padding: 24px 16px;
        box-sizing: border-box;
    }

    .user-sidebar * {
        box-sizing: border-box;
    }

    .user-sidebar .sidebar-brand {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 0 10px 22px;
        color: #fff;
        font-size: 22px;
        font-weight: 700;
        text-decoration: none;
    }

    .user-sidebar .brand-icon {
        width: 36px;
        height: 36px;
        border-radius: 10px;
        background: #7065e8;
        display: inline-flex;
        justify-content: center;
        align-items: center;
    }

    .user-sidebar .sidebar-divider {
        border: 0;
        border-top: 1px solid rgba(255,255,255,.15);
        margin: 0 8px 20px;
    }

    .user-sidebar .sidebar-menu {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .user-sidebar .sidebar-menu li {
        margin-bottom: 7px;
    }

    .user-sidebar .sidebar-link {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 13px;
        border-radius: 9px;
        color: #e7e5ff;
        text-decoration: none;
        font-size: 14px;
        transition: background .2s ease, color .2s ease;
    }

    .user-sidebar .sidebar-link i {
        width: 19px;
        text-align: center;
        font-size: 16px;
    }

    .user-sidebar .sidebar-link:hover {
        background: rgba(255,255,255,.12);
        color: #fff;
    }

    .user-sidebar .sidebar-link.active {
        background: #7165e8;
        color: #fff;
        font-weight: 600;
    }

    .user-sidebar .sidebar-badge {
        margin-left: auto;
        min-width: 20px;
        height: 20px;
        padding: 0 5px;
        border-radius: 20px;
        background: #ef4444;
        color: #fff;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
    }

    .user-sidebar .sidebar-bottom {
        margin-top: auto;
        padding-top: 24px;
    }

    .user-sidebar .sidebar-user {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 8px;
        margin-bottom: 12px;
        border-top: 1px solid rgba(255,255,255,.15);
    }

    .user-sidebar .sidebar-avatar {
        width: 38px;
        height: 38px;
        flex-shrink: 0;
        border-radius: 50%;
        background: #8c83f6;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
    }

    .user-sidebar .sidebar-user-info {
        min-width: 0;
    }

    .user-sidebar .sidebar-user-name {
        font-size: 13px;
        font-weight: 600;
        color: #fff;
    }

    .user-sidebar .sidebar-user-role {
        margin-top: 3px;
        font-size: 11px;
        color: #c7c3f5;
    }

    .user-sidebar .sidebar-admin-link {
        border: 1px solid rgba(255,255,255,.22);
        background: rgba(255,255,255,.06);
    }

    .user-sidebar .sidebar-admin-link:hover {
        background: rgba(255,255,255,.15);
    }

    @media (max-width: 768px) {
        .user-sidebar {
            width: 100%;
            min-width: 0;
            min-height: auto;
            padding: 14px;
        }

        .user-sidebar .sidebar-bottom {
            margin-top: 20px;
            padding-top: 10px;
        }

        .user-sidebar .sidebar-user {
            margin-bottom: 8px;
        }
    }
</style>

<aside class="user-sidebar">

    <!-- LOGO -->
    <a href="<?= htmlspecialchars(userSidebarUrl('user-dashboard'), ENT_QUOTES, 'UTF-8') ?>"
       class="sidebar-brand">
        <span class="brand-icon">
            <i class="fa-solid fa-bug"></i>
        </span>
        <span>BugFlow</span>
    </a>

    <hr class="sidebar-divider">

    <!-- USER MENU -->
    <nav aria-label="Menu người dùng">
        <ul class="sidebar-menu">

            <li>
                <a href="<?= htmlspecialchars(userSidebarUrl('user-dashboard'), ENT_QUOTES, 'UTF-8') ?>"
                   class="sidebar-link <?= userSidebarActive(['user-dashboard', 'user-home'], $currentPage) ?>">
                    <i class="fa-solid fa-house"></i>
                    <span>Trang chủ</span>
                </a>
            </li>

            <li>
                <a href="<?= htmlspecialchars(userSidebarUrl('create'), ENT_QUOTES, 'UTF-8') ?>"
                   class="sidebar-link <?= userSidebarActive('create', $currentPage) ?>">
                    <i class="fa-solid fa-circle-plus"></i>
                    <span>Gửi báo lỗi</span>
                </a>
            </li>

            <li>
                <a href="<?= htmlspecialchars(userSidebarUrl('bugs'), ENT_QUOTES, 'UTF-8') ?>"
                   class="sidebar-link <?= userSidebarActive('bugs', $currentPage) ?>">
                    <i class="fa-solid fa-bug"></i>
                    <span>Báo cáo của tôi</span>
                </a>
            </li>

            <li>
                <a href="<?= htmlspecialchars(userSidebarUrl('notifications'), ENT_QUOTES, 'UTF-8') ?>"
                   class="sidebar-link <?= userSidebarActive('notifications', $currentPage) ?>">
                    <i class="fa-solid fa-bell"></i>
                    <span>Thông báo</span>
                </a>
            </li>

            <li>
                <a href="<?= htmlspecialchars(userSidebarUrl('profile'), ENT_QUOTES, 'UTF-8') ?>"
                   class="sidebar-link <?= userSidebarActive('profile', $currentPage) ?>">
                    <i class="fa-solid fa-user"></i>
                    <span>Hồ sơ cá nhân</span>
                </a>
            </li>

            <li>
                <a href="<?= htmlspecialchars(userSidebarUrl('settings'), ENT_QUOTES, 'UTF-8') ?>"
                   class="sidebar-link <?= userSidebarActive('settings', $currentPage) ?>">
                    <i class="fa-solid fa-gear"></i>
                    <span>Cài đặt</span>
                </a>
            </li>

        </ul>
    </nav>

    <!-- USER INFO AND ADMIN NAVIGATION -->
    <div class="sidebar-bottom">

        <?php
        $sidebarUserName = $_SESSION['user_name']
            ?? $_SESSION['username']
            ?? 'Người dùng';

        $sidebarInitial = function_exists('mb_substr')
            ? mb_strtoupper(mb_substr($sidebarUserName, 0, 1, 'UTF-8'), 'UTF-8')
            : strtoupper(substr($sidebarUserName, 0, 1));
        ?>

        <div class="sidebar-user">
            <div class="sidebar-avatar">
                <?= htmlspecialchars($sidebarInitial, ENT_QUOTES, 'UTF-8') ?>
            </div>

            <div class="sidebar-user-info">
                <div class="sidebar-user-name">
                    <?= htmlspecialchars($sidebarUserName, ENT_QUOTES, 'UTF-8') ?>
                </div>
                <div class="sidebar-user-role">Tài khoản người dùng</div>
            </div>
        </div>

        <a href="<?= htmlspecialchars(userSidebarUrl('admin-dashboard'), ENT_QUOTES, 'UTF-8') ?>"
           class="sidebar-link sidebar-admin-link">
            <i class="fa-solid fa-arrow-left"></i>
            <span>Quay lại Admin</span>
        </a>

    </div>

</aside>

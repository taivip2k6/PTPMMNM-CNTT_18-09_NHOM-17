```php
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$userName = $_SESSION['user_name']
    ?? $_SESSION['username']
    ?? 'Người dùng';

$userEmail = $_SESSION['email'] ?? '';
$userRole = $_SESSION['role'] ?? 'Reporter';

$userInitial = function_exists('mb_substr')
    ? mb_strtoupper(mb_substr($userName, 0, 1, 'UTF-8'), 'UTF-8')
    : strtoupper(substr($userName, 0, 1));

function profileEscape($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ cá nhân | BugFlow</title>

    <link rel="stylesheet" href="/assets/css/user.css">
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>
        .profile-page {
            margin-left: 252px;
            min-height: 100vh;
            padding: 30px;
            background: #f5f7fb;
            color: #1e293b;
            font-family: Inter, Arial, sans-serif;
        }

        .profile-topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 18px;
            margin-bottom: 28px;
        }

        .profile-breadcrumb {
            margin-bottom: 8px;
            color: #8490a5;
            font-size: 13px;
        }

        .profile-topbar h1 {
            margin: 0;
            font-size: 27px;
            font-weight: 750;
        }

        .profile-user {
            display: flex;
            align-items: center;
            gap: 11px;
            padding: 9px 14px;
            border: 1px solid #e8edf5;
            border-radius: 14px;
            background: white;
        }

        .profile-avatar-small {
            display: grid;
            place-items: center;
            width: 38px;
            height: 38px;
            border-radius: 12px;
            background: #e8edff;
            color: #4f46e5;
            font-weight: 800;
        }

        .profile-user-name {
            font-size: 13px;
            font-weight: 700;
        }

        .profile-user-role {
            margin-top: 3px;
            color: #8994a7;
            font-size: 11px;
        }

        .profile-hero {
            display: flex;
            align-items: center;
            gap: 24px;
            padding: 30px;
            margin-bottom: 24px;
            border-radius: 22px;
            color: white;
            background: linear-gradient(120deg, #4338ca, #6366f1 65%, #818cf8);
        }

        .profile-avatar-large {
            display: grid;
            place-items: center;
            width: 92px;
            height: 92px;
            flex-shrink: 0;
            border: 4px solid rgba(255,255,255,.3);
            border-radius: 27px;
            background: rgba(255,255,255,.18);
            font-size: 35px;
            font-weight: 800;
        }

        .profile-hero-info {
            flex: 1;
            min-width: 0;
        }

        .profile-hero-info h2 {
            margin: 0 0 9px;
            font-size: 24px;
            overflow-wrap: anywhere;
        }

        .profile-hero-info p {
            margin: 0 0 14px;
            color: #e0e7ff;
            font-size: 13px;
        }

        .profile-status {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 7px 11px;
            border-radius: 20px;
            background: rgba(255,255,255,.16);
            font-size: 11px;
            font-weight: 700;
        }

        .profile-status-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: #86efac;
        }

        .profile-hero-badge {
            align-self: flex-start;
            padding: 10px 13px;
            border: 1px solid rgba(255,255,255,.2);
            border-radius: 12px;
            background: rgba(255,255,255,.12);
            font-size: 12px;
            white-space: nowrap;
        }

        .profile-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 290px;
            gap: 24px;
            align-items: start;
        }

        .profile-card {
            margin-bottom: 22px;
            overflow: hidden;
            border: 1px solid #e9edf5;
            border-radius: 19px;
            background: white;
            box-shadow: 0 8px 30px rgba(30,41,59,.035);
        }

        .profile-card-header {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 22px 25px;
            border-bottom: 1px solid #edf0f6;
        }

        .profile-card-header-icon {
            display: grid;
            place-items: center;
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: #eef2ff;
            color: #4f46e5;
        }

        .profile-card-header h3 {
            margin: 0 0 5px;
            font-size: 15px;
        }

        .profile-card-header p {
            margin: 0;
            color: #8994a7;
            font-size: 11px;
        }

        .profile-form {
            padding: 25px;
        }

        .profile-fields {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .profile-field {
            min-width: 0;
        }

        .profile-field.full {
            grid-column: 1 / -1;
        }

        .profile-field label {
            display: block;
            margin-bottom: 9px;
            color: #344054;
            font-size: 12px;
            font-weight: 700;
        }

        .profile-field input,
        .profile-field select,
        .profile-field textarea {
            box-sizing: border-box;
            width: 100%;
            padding: 12px 13px;
            border: 1px solid #dfe5ef;
            border-radius: 10px;
            outline: none;
            background: white;
            color: #263247;
            font: inherit;
            font-size: 13px;
            transition: .2s;
        }

        .profile-field input:focus,
        .profile-field select:focus,
        .profile-field textarea:focus {
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99,102,241,.1);
        }

        .profile-field input[readonly] {
            background: #f8fafc;
            color: #64748b;
        }

        .profile-field textarea {
            min-height: 95px;
            resize: vertical;
        }

        .profile-field small {
            display: block;
            margin-top: 7px;
            color: #98a2b3;
            font-size: 10px;
        }

        .profile-form-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            padding-top: 22px;
            margin-top: 23px;
            border-top: 1px solid #edf0f6;
        }

        .profile-btn {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            padding: 12px 17px;
            border: 0;
            border-radius: 10px;
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
        }

        .profile-btn-secondary {
            background: #f1f5f9;
            color: #475569;
        }

        .profile-btn-primary {
            background: #4f46e5;
            color: white;
        }

        .profile-btn-primary:hover {
            background: #4338ca;
        }

        .profile-side-card {
            padding: 23px;
            margin-bottom: 22px;
            border: 1px solid #e9edf5;
            border-radius: 19px;
            background: white;
            box-shadow: 0 8px 30px rgba(30,41,59,.035);
        }

        .profile-side-card h3 {
            margin: 0 0 19px;
            font-size: 15px;
        }

        .profile-detail {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 14px 0;
            border-bottom: 1px solid #f0f2f7;
        }

        .profile-detail:last-child {
            border-bottom: 0;
            padding-bottom: 0;
        }

        .profile-detail-icon {
            display: grid;
            place-items: center;
            width: 35px;
            height: 35px;
            flex-shrink: 0;
            border-radius: 11px;
            background: #f1f5f9;
            color: #64748b;
        }

        .profile-detail-label {
            margin-bottom: 5px;
            color: #98a2b3;
            font-size: 10px;
        }

        .profile-detail-value {
            color: #344054;
            font-size: 12px;
            font-weight: 700;
            overflow-wrap: anywhere;
        }

        .profile-security-note {
            padding: 15px;
            border-radius: 12px;
            background: #eef2ff;
            color: #4338ca;
            font-size: 11px;
            line-height: 1.8;
        }

        .profile-security-note i {
            margin-right: 5px;
        }

        .profile-message {
            display: none;
            padding: 13px 15px;
            margin-bottom: 20px;
            border-radius: 10px;
            background: #dcfce7;
            color: #166534;
            font-size: 12px;
        }

        @media (max-width: 1050px) {
            .profile-grid {
                grid-template-columns: minmax(0, 1fr);
            }

            .profile-side-column {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 18px;
            }
        }

        @media (max-width: 768px) {
            .profile-page {
                margin-left: 0;
                padding: 20px 14px;
            }

            .profile-topbar h1 {
                font-size: 22px;
            }

            .profile-user {
                padding: 7px;
            }

            .profile-user-info {
                display: none;
            }

            .profile-hero {
                flex-wrap: wrap;
                padding: 22px;
                gap: 16px;
            }

            .profile-avatar-large {
                width: 68px;
                height: 68px;
                border-radius: 20px;
                font-size: 27px;
            }

            .profile-hero-info h2 {
                font-size: 19px;
            }

            .profile-hero-badge {
                margin-left: 84px;
            }

            .profile-fields {
                grid-template-columns: 1fr;
            }

            .profile-field.full {
                grid-column: auto;
            }

            .profile-form {
                padding: 20px 16px;
            }

            .profile-card-header {
                padding: 19px 16px;
            }

            .profile-side-column {
                display: block;
            }

            .profile-form-footer {
                flex-direction: column-reverse;
            }

            .profile-btn {
                width: 100%;
                box-sizing: border-box;
            }
        }
    </style>
</head>
<body>

<?php require __DIR__ . '/sidebar.php'; ?>

<main class="profile-page">
    <header class="profile-topbar">
        <div>
            <div class="profile-breadcrumb">
                <i class="fa-solid fa-house"></i>
                &nbsp; Trang người dùng / Hồ sơ cá nhân
            </div>
            <h1>Hồ sơ cá nhân</h1>
        </div>

        <div class="profile-user">
            <div class="profile-avatar-small">
                <?= profileEscape($userInitial) ?>
            </div>
            <div class="profile-user-info">
                <div class="profile-user-name">
                    <?= profileEscape($userName) ?>
                </div>
                <div class="profile-user-role">Người báo cáo</div>
            </div>
        </div>
    </header>

    <section class="profile-hero">
        <div class="profile-avatar-large" id="profileAvatar">
            <?= profileEscape($userInitial) ?>
        </div>

        <div class="profile-hero-info">
            <h2 id="heroName"><?= profileEscape($userName) ?></h2>
            <p id="heroEmail">
                <?= profileEscape($userEmail ?: 'Chưa cập nhật email') ?>
            </p>
            <span class="profile-status">
                <span class="profile-status-dot"></span>
                Tài khoản BugFlow
            </span>
        </div>

        <div class="profile-hero-badge">
            <i class="fa-solid fa-shield-halved"></i>
            <?= profileEscape(ucfirst((string)$userRole)) ?>
        </div>
    </section>

    <div class="profile-grid">
        <div class="profile-main-column">

            <section class="profile-card">
                <div class="profile-card-header">
                    <div class="profile-card-header-icon">
                        <i class="fa-regular fa-user"></i>
                    </div>
                    <div>
                        <h3>Thông tin cá nhân</h3>
                        <p>Thông tin hiển thị trên hồ sơ của bạn.</p>
                    </div>
                </div>

                <form class="profile-form" id="profileForm">
                    <div class="profile-message" id="profileMessage">
                        <i class="fa-solid fa-circle-check"></i>
                        Đã cập nhật phần xem trước hồ sơ trên trang này.
                    </div>

                    <div class="profile-fields">
                        <div class="profile-field">
                            <label for="fullName">Họ và tên</label>
                            <input
                                type="text"
                                id="fullName"
                                name="full_name"
                                value="<?= profileEscape($userName) ?>"
                                maxlength="100"
                                required
                            >
                        </div>

                        <div class="profile-field">
                            <label for="email">Địa chỉ email</label>
                            <input
                                type="email"
                                id="email"
                                name="email"
                                value="<?= profileEscape($userEmail) ?>"
                                placeholder="example@email.com"
                            >
                        </div>

                        <div class="profile-field">
                            <label for="phone">Số điện thoại</label>
                            <input
                                type="tel"
                                id="phone"
                                name="phone"
                                placeholder="Nhập số điện thoại"
                                maxlength="20"
                            >
                        </div>

                        <div class="profile-field">
                            <label for="department">Phòng ban / Nhóm</label>
                            <input
                                type="text"
                                id="department"
                                name="department"
                                placeholder="Ví dụ: Nhóm phát triển web"
                                maxlength="100"
                            >
                        </div>

                        <div class="profile-field full">
                            <label for="bio">Giới thiệu</label>
                            <textarea
                                id="bio"
                                name="bio"
                                maxlength="500"
                                placeholder="Viết một vài dòng giới thiệu về bạn..."
                            ></textarea>
                            <small>Tối đa 500 ký tự.</small>
                        </div>
                    </div>

                    <div class="profile-form-footer">
                        <button type="reset" class="profile-btn profile-btn-secondary">
                            <i class="fa-solid fa-rotate-left"></i>
                            Khôi phục
                        </button>

                        <button type="submit" class="profile-btn profile-btn-primary">
                            <i class="fa-solid fa-floppy-disk"></i>
                            Cập nhật hồ sơ
                        </button>
                    </div>
                </form>
            </section>

            <section class="profile-card">
                <div class="profile-card-header">
                    <div class="profile-card-header-icon">
                        <i class="fa-solid fa-lock"></i>
                    </div>
                    <div>
                        <h3>Bảo mật tài khoản</h3>
                        <p>Các thiết lập giúp bảo vệ tài khoản của bạn.</p>
                    </div>
                </div>

                <div class="profile-form">
                    <div class="profile-field">
                        <label>Tài khoản đăng nhập</label>
                        <input
                            type="text"
                            value="<?= profileEscape($_SESSION['username'] ?? $userName) ?>"
                            readonly
                        >
                        <small>Tên đăng nhập được hiển thị để tham khảo, không thể sửa tại đây.</small>
                    </div>

                    <div style="margin-top:22px">
                        <a href="/?page=settings" class="profile-btn profile-btn-primary">
                            <i class="fa-solid fa-shield-halved"></i>
                            Đi đến cài đặt bảo mật
                        </a>
                    </div>
                </div>
            </section>

        </div>

        <aside class="profile-side-column">
            <section class="profile-side-card">
                <h3>Tổng quan tài khoản</h3>

                <div class="profile-detail">
                    <div class="profile-detail-icon">
                        <i class="fa-solid fa-user-tag"></i>
                    </div>
                    <div>
                        <div class="profile-detail-label">Vai trò</div>
                        <div class="profile-detail-value">
                            <?= profileEscape(ucfirst((string)$userRole)) ?>
                        </div>
                    </div>
                </div>

                <div class="profile-detail">
                    <div class="profile-detail-icon">
                        <i class="fa-regular fa-envelope"></i>
                    </div>
                    <div>
                        <div class="profile-detail-label">Email</div>
                        <div class="profile-detail-value" id="sideEmail">
                            <?= profileEscape($userEmail ?: 'Chưa cập nhật') ?>
                        </div>
                    </div>
                </div>

                <div class="profile-detail">
                    <div class="profile-detail-icon">
                        <i class="fa-solid fa-fingerprint"></i>
                    </div>
                    <div>
                        <div class="profile-detail-label">Tên đăng nhập</div>
                        <div class="profile-detail-value">
                            <?= profileEscape($_SESSION['username'] ?? $userName) ?>
                        </div>
                    </div>
                </div>
            </section>

            <section class="profile-side-card">
                <h3><i class="fa-solid fa-shield-halved"></i> Bảo mật</h3>

                <div class="profile-security-note">
                    <i class="fa-solid fa-circle-info"></i>
                    Không chia sẻ mật khẩu hoặc thông tin đăng nhập với người khác.
                    Nếu cần đổi mật khẩu, hãy sử dụng trang Cài đặt khi chức năng
                    bảo mật đã được kết nối.
                </div>
            </section>
        </aside>
    </div>
</main>

<script>
const profileForm = document.getElementById('profileForm');
const fullNameInput = document.getElementById('fullName');
const emailInput = document.getElementById('email');
const profileMessage = document.getElementById('profileMessage');

const initialProfileValues = {
    fullName: fullNameInput.value,
    email: emailInput.value
};

profileForm.addEventListener('submit', function (event) {
    event.preventDefault();

    if (!profileForm.reportValidity()) {
        return;
    }

    const name = fullNameInput.value.trim();
    const email = emailInput.value.trim();

    if (!name) {
        fullNameInput.focus();
        return;
    }

    const initial = Array.from(name)[0]?.toLocaleUpperCase('vi-VN') || '?';

    document.getElementById('heroName').textContent = name;
    document.getElementById('heroEmail').textContent =
        email || 'Chưa cập nhật email';
    document.getElementById('sideEmail').textContent =
        email || 'Chưa cập nhật';
    document.getElementById('profileAvatar').textContent = initial;

    profileMessage.style.display = 'block';
    profileMessage.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest'
    });
});

profileForm.addEventListener('reset', function () {
    setTimeout(function () {
        document.getElementById('heroName').textContent =
            initialProfileValues.fullName;

        document.getElementById('heroEmail').textContent =
            initialProfileValues.email || 'Chưa cập nhật email';

        document.getElementById('sideEmail').textContent =
            initialProfileValues.email || 'Chưa cập nhật';

        const initial =
            Array.from(initialProfileValues.fullName)[0]
                ?.toLocaleUpperCase('vi-VN') || '?';

        document.getElementById('profileAvatar').textContent = initial;
        profileMessage.style.display = 'none';
    }, 0);
});
</script>

</body>
</html>

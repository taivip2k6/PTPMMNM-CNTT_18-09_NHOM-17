<?php
/**
 * BugFlow - Báo cáo của tôi
 * Dùng chung sidebar và hệ thống màu của khu vực người dùng.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$userName = $_SESSION['user']['name']
    ?? $_SESSION['user_name']
    ?? $_SESSION['username']
    ?? 'Người dùng';

$bugs = [
    ['id' => 1001, 'title' => 'Login button not working', 'project' => 'Website Application', 'priority' => 'High', 'status' => 'Open', 'date' => '25/10/2026'],
    ['id' => 1002, 'title' => 'Profile image upload failed', 'project' => 'Mobile Application', 'priority' => 'Medium', 'status' => 'In Progress', 'date' => '24/10/2026'],
    ['id' => 1003, 'title' => 'API returns 500 error', 'project' => 'Backend API', 'priority' => 'Critical', 'status' => 'Open', 'date' => '23/10/2026'],
    ['id' => 1004, 'title' => 'Dashboard layout breaks on mobile', 'project' => 'Website Application', 'priority' => 'Low', 'status' => 'Resolved', 'date' => '22/10/2026'],
    ['id' => 1005, 'title' => 'Password reset email not received', 'project' => 'Website Application', 'priority' => 'High', 'status' => 'In Progress', 'date' => '21/10/2026'],
    ['id' => 1006, 'title' => 'Incorrect validation message', 'project' => 'Mobile Application', 'priority' => 'Low', 'status' => 'Closed', 'date' => '20/10/2026'],
];

function bfMyBugsEscape($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function bfMyBugsPriority($priority): string {
    return match ($priority) {
        'Low' => 'low', 'Medium' => 'medium', 'High' => 'high', 'Critical' => 'critical',
        default => ''
    };
}
function bfMyBugsStatus($status): string {
    return match ($status) {
        'Open' => 'open', 'In Progress' => 'progress', 'Resolved' => 'resolved', 'Closed' => 'closed',
        default => ''
    };
}
$total = count($bugs);
$open = count(array_filter($bugs, fn($b) => $b['status'] === 'Open'));
$progress = count(array_filter($bugs, fn($b) => $b['status'] === 'In Progress'));
$done = count(array_filter($bugs, fn($b) => in_array($b['status'], ['Resolved', 'Closed'], true)));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Báo cáo của tôi | BugFlow</title>
    <link rel="stylesheet" href="/assets/css/user.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        .bf-mybugs-main{margin-left:252px;min-height:100vh;padding:30px;background:#f5f7fb;color:#202944;font-family:Inter,"Segoe UI",Arial,sans-serif}
        .bf-mybugs-topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:30px;color:#8791a5;font-size:13px}
        .bf-mybugs-avatar{width:42px;height:42px;border-radius:13px;display:grid;place-items:center;background:#e9eaff;color:#5145d9;font-weight:800}
        .bf-mybugs-heading{display:flex;align-items:flex-end;justify-content:space-between;gap:18px;margin-bottom:26px}
        .bf-mybugs-eyebrow{margin:0 0 8px;color:#6a5bea;font-size:11px;font-weight:800;letter-spacing:1.3px}
        .bf-mybugs-heading h1{margin:0;font-size:29px;letter-spacing:-.6px}
        .bf-mybugs-subtitle{margin:8px 0 0;color:#8791a5;font-size:14px}
        .bf-mybugs-button{display:inline-flex;align-items:center;justify-content:center;gap:9px;padding:12px 17px;border:0;border-radius:11px;background:#6558e8;color:white;text-decoration:none;font-weight:700;font-size:13px;white-space:nowrap}
        .bf-mybugs-button:hover{background:#5145d9;color:white}
        .bf-mybugs-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:17px;margin-bottom:24px}
        .bf-mybugs-stat,.bf-mybugs-panel{background:white;border:1px solid #eceef5;border-radius:17px;box-shadow:0 5px 20px rgba(30,41,80,.025)}
        .bf-mybugs-stat{padding:21px}
        .bf-mybugs-stat-label{color:#7e879b;font-size:13px}
        .bf-mybugs-stat-number{font-size:30px;font-weight:800;margin-top:12px;color:#202944}
        .bf-mybugs-stat-note{font-size:12px;color:#9aa2b2;margin-top:5px}
        .bf-mybugs-stat-icon{width:39px;height:39px;display:grid;place-items:center;border-radius:12px;margin-bottom:18px}
        .bf-mybugs-purple{background:#efedff;color:#6558e8}.bf-mybugs-red{background:#fff0f1;color:#e34c5c}.bf-mybugs-orange{background:#fff4e5;color:#db8618}.bf-mybugs-green{background:#e5f8f0;color:#0caa78}
        .bf-mybugs-panel{overflow:hidden}
        .bf-mybugs-panel-head{display:flex;justify-content:space-between;align-items:center;gap:16px;padding:23px 24px;border-bottom:1px solid #edf0f6}
        .bf-mybugs-panel-head h2{margin:0;font-size:17px}.bf-mybugs-panel-head p{margin:6px 0 0;color:#8a93a6;font-size:12px}
        .bf-mybugs-filters{display:flex;gap:9px;flex-wrap:wrap}
        .bf-mybugs-filters input,.bf-mybugs-filters select{height:40px;border:1px solid #e1e6f0;border-radius:9px;padding:0 12px;background:#fff;color:#667085;font-size:12px;max-width:100%}
        .bf-mybugs-table-wrap{overflow-x:auto;padding:0 24px 12px}
        .bf-mybugs-table{width:100%;border-collapse:collapse;min-width:700px}
        .bf-mybugs-table th{text-align:left;background:#f8f9fd;color:#8490a5;font-size:10px;letter-spacing:.5px;padding:15px 13px;font-weight:800}
        .bf-mybugs-table td{padding:17px 13px;border-bottom:1px solid #edf0f6;font-size:12px}
        .bf-mybugs-table tr:last-child td{border-bottom:0}
        .bf-mybugs-id{color:#6558e8;font-weight:800}.bf-mybugs-title{font-weight:700;color:#27324b}.bf-mybugs-project{display:block;color:#929bad;margin-top:5px;font-size:11px}
        .bf-mybugs-pill{display:inline-block;padding:6px 9px;border-radius:7px;font-size:11px;font-weight:700;white-space:nowrap}
        .bf-mybugs-priority-low{color:#12966a}.bf-mybugs-priority-medium{color:#d88413}.bf-mybugs-priority-high,.bf-mybugs-priority-critical{color:#df4656}
        .bf-mybugs-status-open{background:#fff0f1;color:#df4656}.bf-mybugs-status-progress{background:#fff4e5;color:#d88413}.bf-mybugs-status-resolved{background:#e5f8f0;color:#12966a}.bf-mybugs-status-closed{background:#eef1f6;color:#707b90}
        .bf-mybugs-empty{display:none;text-align:center;padding:28px;color:#8791a5;font-size:13px}
        @media(max-width:1000px){.bf-mybugs-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.bf-mybugs-main{padding:22px}}
        @media(max-width:650px){.bf-mybugs-main{margin-left:0;padding:18px}.bf-mybugs-heading{align-items:flex-start;flex-direction:column}.bf-mybugs-panel-head{align-items:flex-start;flex-direction:column}.bf-mybugs-stats{gap:10px}.bf-mybugs-stat{padding:15px}.bf-mybugs-stat-number{font-size:25px}.bf-mybugs-table-wrap{padding:0 12px 10px}}
    </style>
</head>
<body>
<?php require __DIR__ . '/sidebar.php'; ?>
<main class="bf-mybugs-main">
    <header class="bf-mybugs-topbar">
        <span><i class="fa-solid fa-house"></i> &nbsp; Không gian cá nhân / Báo cáo của tôi</span>
        <div class="bf-mybugs-avatar"><?= bfMyBugsEscape(function_exists('mb_substr') ? mb_strtoupper(mb_substr($userName, 0, 1, 'UTF-8'), 'UTF-8') : strtoupper(substr($userName, 0, 1))) ?></div>
    </header>

    <section class="bf-mybugs-heading">
        <div>
            <p class="bf-mybugs-eyebrow">QUẢN LÝ BÁO CÁO</p>
            <h1>Báo cáo của tôi</h1>
            <p class="bf-mybugs-subtitle">Theo dõi trạng thái và tiến độ xử lý các lỗi bạn đã gửi.</p>
        </div>
        <a class="bf-mybugs-button" href="/?page=create"><i class="fa-solid fa-plus"></i> Gửi báo lỗi mới</a>
    </section>

    <section class="bf-mybugs-stats">
        <article class="bf-mybugs-stat"><div class="bf-mybugs-stat-icon bf-mybugs-purple"><i class="fa-solid fa-bug"></i></div><div class="bf-mybugs-stat-label">Tổng báo cáo</div><div class="bf-mybugs-stat-number"><?= $total ?></div><div class="bf-mybugs-stat-note">Tất cả báo cáo của bạn</div></article>
        <article class="bf-mybugs-stat"><div class="bf-mybugs-stat-icon bf-mybugs-red"><i class="fa-solid fa-clock"></i></div><div class="bf-mybugs-stat-label">Đang chờ xử lý</div><div class="bf-mybugs-stat-number"><?= $open ?></div><div class="bf-mybugs-stat-note">Chưa được tiếp nhận xử lý</div></article>
        <article class="bf-mybugs-stat"><div class="bf-mybugs-stat-icon bf-mybugs-orange"><i class="fa-solid fa-arrows-rotate"></i></div><div class="bf-mybugs-stat-label">Đang xử lý</div><div class="bf-mybugs-stat-number"><?= $progress ?></div><div class="bf-mybugs-stat-note">Đội ngũ đang khắc phục</div></article>
        <article class="bf-mybugs-stat"><div class="bf-mybugs-stat-icon bf-mybugs-green"><i class="fa-solid fa-check"></i></div><div class="bf-mybugs-stat-label">Đã hoàn thành</div><div class="bf-mybugs-stat-number"><?= $done ?></div><div class="bf-mybugs-stat-note">Đã giải quyết hoặc đóng</div></article>
    </section>

    <section class="bf-mybugs-panel">
        <div class="bf-mybugs-panel-head">
            <div><h2>Danh sách báo cáo lỗi</h2><p>Tìm kiếm và lọc các lỗi bạn đã báo cáo</p></div>
            <div class="bf-mybugs-filters">
                <input type="search" id="bfBugSearch" placeholder="Tìm báo cáo...">
                <select id="bfStatusFilter"><option value="">Tất cả trạng thái</option><option value="Open">Đang chờ</option><option value="In Progress">Đang xử lý</option><option value="Resolved">Đã giải quyết</option><option value="Closed">Đã đóng</option></select>
                <select id="bfPriorityFilter"><option value="">Tất cả mức ưu tiên</option><option value="Low">Thấp</option><option value="Medium">Trung bình</option><option value="High">Cao</option><option value="Critical">Khẩn cấp</option></select>
            </div>
        </div>
        <div class="bf-mybugs-table-wrap">
            <table class="bf-mybugs-table">
                <thead><tr><th>MÃ BÁO CÁO</th><th>CHI TIẾT LỖI</th><th>ƯU TIÊN</th><th>TRẠNG THÁI</th><th>NGÀY TẠO</th></tr></thead>
                <tbody id="bfBugRows">
                <?php foreach ($bugs as $bug): ?>
                    <tr data-title="<?= bfMyBugsEscape(strtolower($bug['title'].' '.$bug['project'])) ?>" data-status="<?= bfMyBugsEscape($bug['status']) ?>" data-priority="<?= bfMyBugsEscape($bug['priority']) ?>">
                        <td><span class="bf-mybugs-id">#<?= bfMyBugsEscape($bug['id']) ?></span></td>
                        <td><span class="bf-mybugs-title"><?= bfMyBugsEscape($bug['title']) ?></span><span class="bf-mybugs-project"><?= bfMyBugsEscape($bug['project']) ?></span></td>
                        <td><span class="bf-mybugs-priority-<?= bfMyBugsPriority($bug['priority']) ?>"><?= ['Low'=>'Thấp','Medium'=>'Trung bình','High'=>'Cao','Critical'=>'Khẩn cấp'][$bug['priority']] ?? bfMyBugsEscape($bug['priority']) ?></span></td>
                        <td><span class="bf-mybugs-pill bf-mybugs-status-<?= bfMyBugsStatus($bug['status']) ?>"><?= ['Open'=>'Đang chờ','In Progress'=>'Đang xử lý','Resolved'=>'Đã giải quyết','Closed'=>'Đã đóng'][$bug['status']] ?? bfMyBugsEscape($bug['status']) ?></span></td>
                        <td><?= bfMyBugsEscape($bug['date']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <div id="bfBugEmpty" class="bf-mybugs-empty">Không tìm thấy báo cáo phù hợp.</div>
        </div>
    </section>
</main>
<script>
(() => {
    const search = document.getElementById('bfBugSearch');
    const status = document.getElementById('bfStatusFilter');
    const priority = document.getElementById('bfPriorityFilter');
    const rows = [...document.querySelectorAll('#bfBugRows tr')];
    const empty = document.getElementById('bfBugEmpty');
    function filterRows() {
        const q = search.value.trim().toLocaleLowerCase('vi');
        let visible = 0;
        rows.forEach(row => {
            const match = row.dataset.title.includes(q)
                && (!status.value || row.dataset.status === status.value)
                && (!priority.value || row.dataset.priority === priority.value);
            row.style.display = match ? '' : 'none';
            if (match) visible++;
        });
        empty.style.display = visible ? 'none' : 'block';
    }
    search.addEventListener('input', filterRows);
    status.addEventListener('change', filterRows);
    priority.addEventListener('change', filterRows);
})();
</script>
</body>
</html>

```php
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$userName = $_SESSION['user_name']
    ?? $_SESSION['username']
    ?? 'Người dùng';

$userInitial = function_exists('mb_substr')
    ? mb_strtoupper(mb_substr($userName, 0, 1, 'UTF-8'), 'UTF-8')
    : strtoupper(substr($userName, 0, 1));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Báo cáo lỗi | BugFlow</title>

    <!-- CSS dùng chung của khu vực người dùng -->
    <link rel="stylesheet" href="/assets/css/user.css">

    <!-- Icon -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>
        .create-page {
            margin-left: 252px;
            min-height: 100vh;
            padding: 30px;
            background: #f5f7fb;
            color: #1e293b;
            font-family: Inter, Arial, sans-serif;
        }

        .create-topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .create-breadcrumb {
            color: #8490a5;
            font-size: 13px;
            margin-bottom: 8px;
        }

        .create-topbar h1 {
            margin: 0;
            font-size: 27px;
            font-weight: 750;
        }

        .create-user {
            display: flex;
            align-items: center;
            gap: 11px;
            padding: 9px 14px;
            background: white;
            border: 1px solid #e8edf5;
            border-radius: 14px;
        }

        .create-avatar {
            width: 38px;
            height: 38px;
            display: grid;
            place-items: center;
            border-radius: 12px;
            background: #e8edff;
            color: #4f46e5;
            font-weight: 800;
        }

        .create-user-name {
            font-size: 13px;
            font-weight: 700;
        }

        .create-user-role {
            color: #8994a7;
            font-size: 11px;
            margin-top: 3px;
        }

        .create-intro {
            position: relative;
            overflow: hidden;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            padding: 28px 32px;
            margin-bottom: 24px;
            border-radius: 22px;
            color: white;
            background: linear-gradient(120deg, #4338ca, #6366f1 65%, #818cf8);
        }

        .create-intro h2 {
            margin: 0 0 10px;
            font-size: 23px;
        }

        .create-intro p {
            margin: 0;
            color: #e0e7ff;
            font-size: 14px;
            line-height: 1.7;
            max-width: 560px;
        }

        .create-intro-icon {
            width: 78px;
            height: 78px;
            flex-shrink: 0;
            display: grid;
            place-items: center;
            border-radius: 24px;
            background: rgba(255,255,255,.15);
            font-size: 34px;
        }

        .create-layout {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 290px;
            gap: 24px;
            align-items: start;
        }

        .create-card,
        .create-guide {
            background: white;
            border: 1px solid #e9edf5;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(30, 41, 59, .035);
        }

        .create-card-header {
            padding: 23px 26px;
            border-bottom: 1px solid #edf0f6;
        }

        .create-card-header h3 {
            margin: 0 0 7px;
            font-size: 17px;
        }

        .create-card-header p {
            margin: 0;
            color: #8792a5;
            font-size: 13px;
        }

        .create-form {
            padding: 26px;
        }

        .create-form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 21px;
        }

        .create-field {
            min-width: 0;
            margin-bottom: 21px;
        }

        .create-field.full {
            grid-column: 1 / -1;
        }

        .create-field label {
            display: block;
            margin-bottom: 9px;
            font-size: 13px;
            font-weight: 700;
            color: #344054;
        }

        .create-field label span {
            color: #ef4444;
        }

        .create-field input,
        .create-field select,
        .create-field textarea {
            width: 100%;
            box-sizing: border-box;
            padding: 13px 14px;
            border: 1px solid #dfe5ef;
            border-radius: 11px;
            outline: none;
            background: #fff;
            color: #263247;
            font: inherit;
            font-size: 13px;
            transition: .2s;
        }

        .create-field input:focus,
        .create-field select:focus,
        .create-field textarea:focus {
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99,102,241,.11);
        }

        .create-field textarea {
            min-height: 125px;
            resize: vertical;
            line-height: 1.6;
        }

        .create-field .short-textarea {
            min-height: 95px;
        }

        .create-help {
            display: block;
            margin-top: 7px;
            color: #98a2b3;
            font-size: 11px;
            line-height: 1.5;
        }

        .create-priority {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 10px;
        }

        .create-priority-option {
            position: relative;
        }

        .create-priority-option input {
            position: absolute;
            opacity: 0;
            pointer-events: none;
        }

        .create-priority-option label {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 7px;
            padding: 13px 8px;
            margin: 0;
            border: 1px solid #e2e8f0;
            border-radius: 11px;
            cursor: pointer;
            font-size: 12px;
            transition: .2s;
        }

        .create-priority-option input:checked + label {
            border-color: #6366f1;
            background: #eef2ff;
            color: #4338ca;
        }

        .create-priority-option .low {
            color: #16a34a;
        }

        .create-priority-option .medium {
            color: #d97706;
        }

        .create-priority-option .high {
            color: #dc2626;
        }

        .create-upload {
            display: block;
            padding: 24px 16px;
            border: 1px dashed #cbd5e1;
            border-radius: 13px;
            background: #fafbff;
            text-align: center;
            cursor: pointer;
        }

        .create-upload i {
            display: block;
            margin-bottom: 10px;
            color: #6366f1;
            font-size: 25px;
        }

        .create-upload strong {
            display: block;
            margin-bottom: 6px;
            font-size: 13px;
        }

        .create-upload small {
            color: #98a2b3;
            font-size: 11px;
        }

        .create-upload input {
            display: none;
        }

        .create-file-name {
            display: block;
            margin-top: 10px;
            color: #4f46e5;
            font-size: 12px;
            overflow-wrap: anywhere;
        }

        .create-form-footer {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding-top: 22px;
            border-top: 1px solid #edf0f6;
        }

        .create-btn {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            padding: 12px 19px;
            border: 0;
            border-radius: 11px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            transition: .2s;
        }

        .create-btn-cancel {
            background: #f1f5f9;
            color: #475569;
        }

        .create-btn-submit {
            background: #4f46e5;
            color: white;
            box-shadow: 0 5px 14px rgba(79,70,229,.18);
        }

        .create-btn-submit:hover {
            background: #4338ca;
            transform: translateY(-1px);
        }

        .create-guide {
            padding: 23px;
        }

        .create-guide h3 {
            margin: 0 0 20px;
            font-size: 16px;
        }

        .create-guide-item {
            display: flex;
            gap: 12px;
            margin-bottom: 22px;
        }

        .create-guide-icon {
            width: 38px;
            height: 38px;
            flex-shrink: 0;
            display: grid;
            place-items: center;
            border-radius: 12px;
            background: #eef2ff;
            color: #4f46e5;
        }

        .create-guide-item strong {
            display: block;
            margin-bottom: 5px;
            font-size: 12px;
        }

        .create-guide-item p {
            margin: 0;
            color: #8792a5;
            font-size: 11px;
            line-height: 1.65;
        }

        .create-guide-note {
            padding: 15px;
            border-radius: 13px;
            background: #fff7ed;
            color: #9a3412;
            font-size: 12px;
            line-height: 1.7;
        }

        .create-guide-note i {
            margin-right: 5px;
        }

        @media (max-width: 1100px) {
            .create-layout {
                grid-template-columns: minmax(0, 1fr);
            }

            .create-guide {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 14px;
            }

            .create-guide h3,
            .create-guide-note {
                grid-column: 1 / -1;
            }
        }

        @media (max-width: 768px) {
            .create-page {
                margin-left: 0;
                padding: 20px 14px;
            }

            .create-topbar h1 {
                font-size: 22px;
            }

            .create-user {
                padding: 7px;
            }

            .create-user-info {
                display: none;
            }

            .create-intro {
                padding: 22px;
            }

            .create-intro h2 {
                font-size: 19px;
            }

            .create-intro-icon {
                width: 54px;
                height: 54px;
                font-size: 25px;
            }

            .create-form {
                padding: 20px 16px;
            }

            .create-form-grid {
                grid-template-columns: 1fr;
                gap: 0;
            }

            .create-field.full {
                grid-column: auto;
            }

            .create-priority {
                grid-template-columns: 1fr;
            }

            .create-guide {
                display: block;
            }

            .create-form-footer {
                flex-direction: column-reverse;
            }

            .create-btn {
                width: 100%;
                box-sizing: border-box;
            }
        }
    </style>
</head>
<body>

<?php require __DIR__ . '/sidebar.php'; ?>

<main class="create-page">
    <header class="create-topbar">
        <div>
            <div class="create-breadcrumb">
                <i class="fa-solid fa-house"></i>
                &nbsp; Trang người dùng / Báo cáo lỗi
            </div>
            <h1>Báo cáo lỗi mới</h1>
        </div>

        <div class="create-user">
            <div class="create-avatar">
                <?= htmlspecialchars($userInitial, ENT_QUOTES, 'UTF-8') ?>
            </div>
            <div class="create-user-info">
                <div class="create-user-name">
                    <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?>
                </div>
                <div class="create-user-role">Người báo cáo</div>
            </div>
        </div>
    </header>

    <section class="create-intro">
        <div>
            <h2><i class="fa-solid fa-bug"></i> Phát hiện vấn đề?</h2>
            <p>
                Hãy mô tả lỗi bạn gặp phải càng rõ ràng càng tốt.
                Thông tin của bạn sẽ giúp đội ngũ phát triển xác định
                nguyên nhân và xử lý nhanh hơn.
            </p>
        </div>
        <div class="create-intro-icon">
            <i class="fa-solid fa-file-circle-plus"></i>
        </div>
    </section>

    <div class="create-layout">
        <section class="create-card">
            <div class="create-card-header">
                <h3>Thông tin sự cố</h3>
                <p>Các trường có dấu <span style="color:#ef4444">*</span> là bắt buộc.</p>
            </div>

            <form class="create-form"
                  id="bugForm"
                  method="POST"
                  action=""
                  enctype="multipart/form-data">

                <div class="create-form-grid">
                    <div class="create-field full">
                        <label for="bugTitle">Tiêu đề lỗi <span>*</span></label>
                        <input
                            type="text"
                            id="bugTitle"
                            name="title"
                            placeholder="Ví dụ: Không thể đăng nhập vào hệ thống"
                            maxlength="150"
                            required
                        >
                    </div>

                    <div class="create-field">
                        <label for="bugProject">Dự án <span>*</span></label>
                        <select id="bugProject" name="project" required>
                            <option value="">-- Chọn dự án --</option>
                            <option value="website">Website</option>
                            <option value="mobile">Ứng dụng di động</option>
                            <option value="admin">Hệ thống quản trị</option>
                            <option value="other">Khác</option>
                        </select>
                    </div>

                    <div class="create-field">
                        <label for="bugEnvironment">Môi trường phát hiện</label>
                        <select id="bugEnvironment" name="environment">
                            <option value="development">Development</option>
                            <option value="testing">Testing</option>
                            <option value="production">Production</option>
                        </select>
                    </div>

                    <div class="create-field full">
                        <label>Mức độ ưu tiên <span>*</span></label>
                        <div class="create-priority">
                            <div class="create-priority-option">
                                <input type="radio" id="priorityLow"
                                       name="priority" value="low">
                                <label for="priorityLow">
                                    <i class="fa-solid fa-circle low"></i> Thấp
                                </label>
                            </div>

                            <div class="create-priority-option">
                                <input type="radio" id="priorityMedium"
                                       name="priority" value="medium" checked>
                                <label for="priorityMedium">
                                    <i class="fa-solid fa-circle medium"></i> Trung bình
                                </label>
                            </div>

                            <div class="create-priority-option">
                                <input type="radio" id="priorityHigh"
                                       name="priority" value="high">
                                <label for="priorityHigh">
                                    <i class="fa-solid fa-circle high"></i> Cao
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="create-field full">
                        <label for="bugDescription">Mô tả lỗi <span>*</span></label>
                        <textarea
                            id="bugDescription"
                            name="description"
                            placeholder="Lỗi xảy ra trong tình huống nào? Bạn đã thực hiện thao tác gì trước đó?"
                            required
                        ></textarea>
                        <small class="create-help">
                            Hãy cung cấp đủ thông tin để người xử lý hiểu vấn đề.
                        </small>
                    </div>

                    <div class="create-field full">
                        <label for="bugSteps">Các bước tái hiện lỗi</label>
                        <textarea
                            class="short-textarea"
                            id="bugSteps"
                            name="steps"
                            placeholder="1. Mở trang đăng nhập&#10;2. Nhập thông tin&#10;3. Nhấn nút Đăng nhập"
                        ></textarea>
                    </div>

                    <div class="create-field full">
                        <label for="bugAttachment">Ảnh chụp hoặc tệp đính kèm</label>
                        <label class="create-upload" for="bugAttachment">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                            <strong>Nhấn để chọn tệp</strong>
                            <small>Ảnh hoặc tài liệu, tối đa 5 MB mỗi tệp</small>
                            <input
                                type="file"
                                id="bugAttachment"
                                name="attachment"
                                accept="image/*,.pdf,.txt,.log"
                            >
                            <span class="create-file-name" id="fileName"></span>
                        </label>
                    </div>
                </div>

                <div class="create-form-footer">
                    <a href="/?page=bugs" class="create-btn create-btn-cancel">
                        Hủy
                    </a>

                    <button type="submit" class="create-btn create-btn-submit">
                        <i class="fa-solid fa-paper-plane"></i>
                        Gửi báo cáo
                    </button>
                </div>
            </form>
        </section>

        <aside class="create-guide">
            <h3><i class="fa-regular fa-lightbulb"></i> Mẹo báo cáo lỗi</h3>

            <div class="create-guide-item">
                <div class="create-guide-icon">
                    <i class="fa-solid fa-heading"></i>
                </div>
                <div>
                    <strong>Tiêu đề cụ thể</strong>
                    <p>Nêu rõ chức năng bị lỗi và vấn đề đang xảy ra.</p>
                </div>
            </div>

            <div class="create-guide-item">
                <div class="create-guide-icon">
                    <i class="fa-solid fa-list-ol"></i>
                </div>
                <div>
                    <strong>Mô tả từng bước</strong>
                    <p>Ghi lại các thao tác để người khác có thể tái hiện lỗi.</p>
                </div>
            </div>

            <div class="create-guide-item">
                <div class="create-guide-icon">
                    <i class="fa-solid fa-image"></i>
                </div>
                <div>
                    <strong>Đính kèm minh chứng</strong>
                    <p>Ảnh chụp màn hình giúp đội ngũ hiểu vấn đề nhanh hơn.</p>
                </div>
            </div>

            <div class="create-guide-item">
                <div class="create-guide-icon">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                </div>
                <div>
                    <strong>Chọn mức độ phù hợp</strong>
                    <p>Đánh dấu mức độ cao nếu lỗi ảnh hưởng nghiêm trọng đến chức năng chính.</p>
                </div>
            </div>

            <div class="create-guide-note">
                <i class="fa-solid fa-circle-info"></i>
                <strong>Lưu ý:</strong> Hiện tại form này mới có giao diện và kiểm tra dữ liệu cơ bản ở trình duyệt. Chức năng lưu báo cáo vào cơ sở dữ liệu cần được kết nối với backend PHP.
            </div>
        </aside>
    </div>
</main>

<script>
const attachmentInput = document.getElementById('bugAttachment');
const fileNameDisplay = document.getElementById('fileName');
const bugForm = document.getElementById('bugForm');

attachmentInput.addEventListener('change', function () {
    const file = this.files[0];

    if (!file) {
        fileNameDisplay.textContent = '';
        return;
    }

    const maxSize = 5 * 1024 * 1024;

    if (file.size > maxSize) {
        alert('Tệp vượt quá 5 MB. Vui lòng chọn tệp nhỏ hơn.');
        this.value = '';
        fileNameDisplay.textContent = '';
        return;
    }

    fileNameDisplay.textContent = 'Đã chọn: ' + file.name;
});

bugForm.addEventListener('submit', function (event) {
    // Chưa gửi dữ liệu lên cơ sở dữ liệu ở phiên bản giao diện này.
    event.preventDefault();

    if (!bugForm.reportValidity()) {
        return;
    }

    alert('Giao diện đã kiểm tra dữ liệu. Bước tiếp theo cần kết nối PHP với cơ sở dữ liệu để lưu báo cáo.');
});
</script>

</body>
</html>
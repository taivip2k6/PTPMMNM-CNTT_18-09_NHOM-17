```php
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$userName = $_SESSION['user_name']
    ?? $_SESSION['username']
    ?? 'Người dùng';

$userEmail = $_SESSION['email'] ?? '';

$userInitial = function_exists('mb_substr')
    ? mb_strtoupper(mb_substr($userName, 0, 1, 'UTF-8'), 'UTF-8')
    : strtoupper(substr($userName, 0, 1));

function settingsEscape($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cài đặt | BugFlow</title>

    <link rel="stylesheet" href="/assets/css/user.css">
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>
        .settings-page {
            margin-left: 252px;
            min-height: 100vh;
            padding: 30px;
            background: #f5f7fb;
            color: #1e293b;
            font-family: Inter, Arial, sans-serif;
        }

        .settings-topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 18px;
            margin-bottom: 28px;
        }

        .settings-breadcrumb {
            margin-bottom: 8px;
            color: #8490a5;
            font-size: 13px;
        }

        .settings-topbar h1 {
            margin: 0;
            font-size: 27px;
            font-weight: 750;
        }

        .settings-user {
            display: flex;
            align-items: center;
            gap: 11px;
            padding: 9px 14px;
            border: 1px solid #e8edf5;
            border-radius: 14px;
            background: white;
        }

        .settings-avatar {
            display: grid;
            place-items: center;
            width: 38px;
            height: 38px;
            border-radius: 12px;
            background: #e8edff;
            color: #4f46e5;
            font-weight: 800;
        }

        .settings-user-name {
            font-size: 13px;
            font-weight: 700;
        }

        .settings-user-role {
            margin-top: 3px;
            color: #8994a7;
            font-size: 11px;
        }

        .settings-banner {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            padding: 27px 30px;
            margin-bottom: 24px;
            border-radius: 21px;
            color: white;
            background: linear-gradient(120deg, #4338ca, #6366f1 65%, #818cf8);
        }

        .settings-banner h2 {
            margin: 0 0 9px;
            font-size: 23px;
        }

        .settings-banner p {
            margin: 0;
            color: #e0e7ff;
            font-size: 13px;
            line-height: 1.7;
        }

        .settings-banner-icon {
            display: grid;
            place-items: center;
            width: 70px;
            height: 70px;
            flex-shrink: 0;
            border-radius: 22px;
            background: rgba(255,255,255,.15);
            font-size: 29px;
        }

        .settings-layout {
            display: grid;
            grid-template-columns: 220px minmax(0, 1fr);
            gap: 22px;
            align-items: start;
        }

        .settings-nav,
        .settings-card {
            border: 1px solid #e9edf5;
            border-radius: 18px;
            background: white;
            box-shadow: 0 8px 30px rgba(30,41,59,.035);
        }

        .settings-nav {
            padding: 12px;
        }

        .settings-nav-title {
            padding: 12px 10px;
            color: #98a2b3;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: .8px;
            text-transform: uppercase;
        }

        .settings-nav-link {
            display: flex;
            align-items: center;
            gap: 11px;
            padding: 12px 11px;
            margin-bottom: 5px;
            border-radius: 10px;
            color: #64748b;
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
        }

        .settings-nav-link i {
            width: 17px;
            text-align: center;
        }

        .settings-nav-link:hover,
        .settings-nav-link.active {
            background: #eef2ff;
            color: #4338ca;
        }

        .settings-card {
            overflow: hidden;
            margin-bottom: 20px;
            scroll-margin-top: 20px;
        }

        .settings-card-header {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 22px 25px;
            border-bottom: 1px solid #edf0f6;
        }

        .settings-card-icon {
            display: grid;
            place-items: center;
            width: 40px;
            height: 40px;
            flex-shrink: 0;
            border-radius: 12px;
            background: #eef2ff;
            color: #4f46e5;
        }

        .settings-card-icon.green {
            background: #dcfce7;
            color: #15803d;
        }

        .settings-card-icon.orange {
            background: #ffedd5;
            color: #c2410c;
        }

        .settings-card-header h3 {
            margin: 0 0 5px;
            font-size: 15px;
        }

        .settings-card-header p {
            margin: 0;
            color: #8994a7;
            font-size: 11px;
            line-height: 1.5;
        }

        .settings-card-body {
            padding: 8px 25px;
        }

        .settings-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            padding: 19px 0;
            border-bottom: 1px solid #f0f2f7;
        }

        .settings-row:last-child {
            border-bottom: 0;
        }

        .settings-row-info {
            flex: 1;
            min-width: 0;
        }

        .settings-row-title {
            margin-bottom: 6px;
            color: #344054;
            font-size: 13px;
            font-weight: 700;
        }

        .settings-row-description {
            color: #8994a7;
            font-size: 11px;
            line-height: 1.7;
        }

        .settings-select {
            width: 160px;
            max-width: 45%;
            padding: 10px 11px;
            border: 1px solid #dfe5ef;
            border-radius: 9px;
            background: white;
            color: #344054;
            font-size: 12px;
            outline: none;
        }

        .settings-switch {
            position: relative;
            display: inline-block;
            width: 42px;
            height: 24px;
            flex-shrink: 0;
        }

        .settings-switch input {
            width: 0;
            height: 0;
            opacity: 0;
        }

        .settings-switch-slider {
            position: absolute;
            inset: 0;
            border-radius: 20px;
            background: #cbd5e1;
            cursor: pointer;
            transition: .2s;
        }

        .settings-switch-slider::before {
            position: absolute;
            bottom: 3px;
            left: 3px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: white;
            content: "";
            transition: .2s;
        }

        .settings-switch input:checked + .settings-switch-slider {
            background: #6366f1;
        }

        .settings-switch input:checked + .settings-switch-slider::before {
            transform: translateX(18px);
        }

        .settings-switch input:focus-visible + .settings-switch-slider {
            outline: 3px solid rgba(99,102,241,.25);
        }

        .settings-inline-button {
            padding: 9px 12px;
            border: 1px solid #e0e7ff;
            border-radius: 9px;
            background: #eef2ff;
            color: #4338ca;
            font-size: 11px;
            font-weight: 700;
            text-decoration: none;
            white-space: nowrap;
            cursor: pointer;
        }

        .settings-inline-button:hover {
            background: #e0e7ff;
        }

        .settings-danger {
            border-color: #fee2e2;
        }

        .settings-danger .settings-card-icon {
            background: #fee2e2;
            color: #b91c1c;
        }

        .settings-danger-button {
            padding: 10px 12px;
            border: 1px solid #fecaca;
            border-radius: 9px;
            background: #fff1f2;
            color: #be123c;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
        }

        .settings-save-area {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            padding: 5px 0 25px;
        }

        .settings-button {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            padding: 12px 17px;
            border: 0;
            border-radius: 10px;
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
        }

        .settings-button-secondary {
            background: #f1f5f9;
            color: #475569;
        }

        .settings-button-primary {
            background: #4f46e5;
            color: white;
        }

        .settings-button-primary:hover {
            background: #4338ca;
        }

        .settings-message {
            display: none;
            padding: 13px 15px;
            margin-bottom: 18px;
            border-radius: 10px;
            background: #dcfce7;
            color: #166534;
            font-size: 12px;
            line-height: 1.6;
        }

        .settings-message.show {
            display: block;
        }

        .settings-note {
            padding: 14px;
            border-radius: 11px;
            background: #eef2ff;
            color: #4338ca;
            font-size: 11px;
            line-height: 1.8;
        }

        @media (max-width: 1000px) {
            .settings-layout {
                grid-template-columns: 1fr;
            }

            .settings-nav {
                display: flex;
                flex-wrap: wrap;
                gap: 5px;
            }

            .settings-nav-title {
                width: 100%;
            }

            .settings-nav-link {
                margin-bottom: 0;
            }
        }

        @media (max-width: 768px) {
            .settings-page {
                margin-left: 0;
                padding: 20px 14px;
            }

            .settings-topbar h1 {
                font-size: 22px;
            }

            .settings-user {
                padding: 7px;
            }

            .settings-user-info {
                display: none;
            }

            .settings-banner {
                padding: 22px;
            }

            .settings-banner h2 {
                font-size: 19px;
            }

            .settings-banner-icon {
                width: 52px;
                height: 52px;
                font-size: 23px;
            }

            .settings-card-header {
                padding: 18px 16px;
            }

            .settings-card-body {
                padding: 5px 16px;
            }

            .settings-row {
                align-items: flex-start;
                gap: 12px;
            }

            .settings-row-description {
                max-width: 290px;
            }

            .settings-select {
                width: 125px;
            }

            .settings-save-area {
                flex-direction: column-reverse;
            }

            .settings-button {
                width: 100%;
                box-sizing: border-box;
            }
        }
    </style>
</head>
<body>

<?php require __DIR__ . '/sidebar.php'; ?>

<main class="settings-page">
    <header class="settings-topbar">
        <div>
            <div class="settings-breadcrumb">
                <i class="fa-solid fa-house"></i>
                &nbsp; Trang người dùng / Cài đặt
            </div>
            <h1>Cài đặt</h1>
        </div>

        <div class="settings-user">
            <div class="settings-avatar">
                <?= settingsEscape($userInitial) ?>
            </div>
            <div class="settings-user-info">
                <div class="settings-user-name">
                    <?= settingsEscape($userName) ?>
                </div>
                <div class="settings-user-role">Người báo cáo</div>
            </div>
        </div>
    </header>

    <section class="settings-banner">
        <div>
            <h2><i class="fa-solid fa-sliders"></i> Tùy chỉnh trải nghiệm</h2>
            <p>
                Quản lý tùy chọn thông báo, giao diện và các thiết lập
                tài khoản của bạn tại một nơi.
            </p>
        </div>
        <div class="settings-banner-icon">
            <i class="fa-solid fa-gear"></i>
        </div>
    </section>

    <div class="settings-layout">
        <nav class="settings-nav">
            <div class="settings-nav-title">Danh mục cài đặt</div>

            <a href="#account" class="settings-nav-link active">
                <i class="fa-regular fa-user"></i>
                Tài khoản
            </a>

            <a href="#notifications" class="settings-nav-link">
                <i class="fa-regular fa-bell"></i>
                Thông báo
            </a>

            <a href="#appearance" class="settings-nav-link">
                <i class="fa-solid fa-palette"></i>
                Giao diện
            </a>

            <a href="#security" class="settings-nav-link">
                <i class="fa-solid fa-shield-halved"></i>
                Bảo mật
            </a>
        </nav>

        <div class="settings-content">
            <div class="settings-message" id="settingsMessage" role="status">
                <i class="fa-solid fa-circle-check"></i>
                <span id="settingsMessageText"></span>
            </div>

            <section class="settings-card" id="account">
                <div class="settings-card-header">
                    <div class="settings-card-icon">
                        <i class="fa-regular fa-user"></i>
                    </div>
                    <div>
                        <h3>Tài khoản</h3>
                        <p>Thông tin nhận diện tài khoản của bạn.</p>
                    </div>
                </div>

                <div class="settings-card-body">
                    <div class="settings-row">
                        <div class="settings-row-info">
                            <div class="settings-row-title">Tên hiển thị</div>
                            <div class="settings-row-description">
                                <?= settingsEscape($userName) ?>
                            </div>
                        </div>
                        <a href="/?page=profile" class="settings-inline-button">
                            Chỉnh sửa hồ sơ
                        </a>
                    </div>

                    <div class="settings-row">
                        <div class="settings-row-info">
                            <div class="settings-row-title">Địa chỉ email</div>
                            <div class="settings-row-description">
                                <?= settingsEscape($userEmail ?: 'Chưa cập nhật email') ?>
                            </div>
                        </div>
                        <a href="/?page=profile" class="settings-inline-button">
                            Cập nhật
                        </a>
                    </div>

                    <div class="settings-row">
                        <div class="settings-row-info">
                            <div class="settings-row-title">Ngôn ngữ</div>
                            <div class="settings-row-description">
                                Chọn ngôn ngữ hiển thị trên giao diện.
                            </div>
                        </div>
                        <select class="settings-select" id="languageSetting">
                            <option value="vi">Tiếng Việt</option>
                            <option value="en">English</option>
                        </select>
                    </div>
                </div>
            </section>

            <section class="settings-card" id="notifications">
                <div class="settings-card-header">
                    <div class="settings-card-icon orange">
                        <i class="fa-regular fa-bell"></i>
                    </div>
                    <div>
                        <h3>Thông báo</h3>
                        <p>Chọn những cập nhật bạn muốn theo dõi.</p>
                    </div>
                </div>

                <div class="settings-card-body">
                    <div class="settings-row">
                        <div class="settings-row-info">
                            <div class="settings-row-title">Cập nhật báo cáo lỗi</div>
                            <div class="settings-row-description">
                                Khi trạng thái báo cáo được thay đổi.
                            </div>
                        </div>
                        <label class="settings-switch">
                            <input type="checkbox" id="reportNotifications" checked>
                            <span class="settings-switch-slider"></span>
                        </label>
                    </div>

                    <div class="settings-row">
                        <div class="settings-row-info">
                            <div class="settings-row-title">Bình luận mới</div>
                            <div class="settings-row-description">
                                Khi có phản hồi mới trên báo cáo của bạn.
                            </div>
                        </div>
                        <label class="settings-switch">
                            <input type="checkbox" id="commentNotifications" checked>
                            <span class="settings-switch-slider"></span>
                        </label>
                    </div>

                    <div class="settings-row">
                        <div class="settings-row-info">
                            <div class="settings-row-title">Thông báo hệ thống</div>
                            <div class="settings-row-description">
                                Các thông tin và cập nhật chung từ hệ thống.
                            </div>
                        </div>
                        <label class="settings-switch">
                            <input type="checkbox" id="systemNotifications">
                            <span class="settings-switch-slider"></span>
                        </label>
                    </div>
                </div>
            </section>

            <section class="settings-card" id="appearance">
                <div class="settings-card-header">
                    <div class="settings-card-icon green">
                        <i class="fa-solid fa-palette"></i>
                    </div>
                    <div>
                        <h3>Giao diện</h3>
                        <p>Tùy chỉnh cách hiển thị của trang người dùng.</p>
                    </div>
                </div>

                <div class="settings-card-body">
                    <div class="settings-row">
                        <div class="settings-row-info">
                            <div class="settings-row-title">Chế độ hiển thị</div>
                            <div class="settings-row-description">
                                Lựa chọn giao diện sáng hoặc tối.
                            </div>
                        </div>
                        <select class="settings-select" id="themeSetting">
                            <option value="light">Sáng</option>
                            <option value="dark">Tối</option>
                        </select>
                    </div>

                    <div class="settings-row">
                        <div class="settings-row-info">
                            <div class="settings-row-title">Hiệu ứng chuyển động</div>
                            <div class="settings-row-description">
                                Bật hoặc tắt hiệu ứng chuyển động trên giao diện.
                            </div>
                        </div>
                        <label class="settings-switch">
                            <input type="checkbox" id="animationSetting" checked>
                            <span class="settings-switch-slider"></span>
                        </label>
                    </div>
                </div>
            </section>

            <section class="settings-card" id="security">
                <div class="settings-card-header">
                    <div class="settings-card-icon">
                        <i class="fa-solid fa-shield-halved"></i>
                    </div>
                    <div>
                        <h3>Bảo mật</h3>
                        <p>Các tùy chọn liên quan đến quyền truy cập tài khoản.</p>
                    </div>
                </div>

                <div class="settings-card-body">
                    <div class="settings-row">
                        <div class="settings-row-info">
                            <div class="settings-row-title">Mật khẩu</div>
                            <div class="settings-row-description">
                                Sử dụng chức năng đổi mật khẩu khi backend đã hỗ trợ.
                            </div>
                        </div>
                        <button type="button" class="settings-inline-button"
                                id="changePasswordButton">
                            Đổi mật khẩu
                        </button>
                    </div>

                    <div class="settings-row">
                        <div class="settings-row-info">
                            <div class="settings-row-title">Đăng xuất</div>
                            <div class="settings-row-description">
                                Kết thúc phiên đăng nhập trên thiết bị hiện tại.
                            </div>
                        </div>
                        <a href="/logout.php" class="settings-danger-button">
                            <i class="fa-solid fa-right-from-bracket"></i>
                            Đăng xuất
                        </a>
                    </div>
                </div>
            </section>

            <div class="settings-note">
                <i class="fa-solid fa-circle-info"></i>
                <strong>Lưu ý:</strong> Các tùy chọn giao diện và thông báo trong phiên bản này
                được lưu trên trình duyệt hiện tại. Muốn đồng bộ giữa các thiết bị,
                bạn cần kết nối chúng với backend và cơ sở dữ liệu.
            </div>

            <div class="settings-save-area">
                <button type="button" class="settings-button settings-button-secondary"
                        id="resetSettings">
                    Khôi phục mặc định
                </button>

                <button type="button" class="settings-button settings-button-primary"
                        id="saveSettings">
                    <i class="fa-solid fa-floppy-disk"></i>
                    Lưu cài đặt
                </button>
            </div>
        </div>
    </div>
</main>

<script>
const settingControls = {
    language: document.getElementById('languageSetting'),
    reportNotifications: document.getElementById('reportNotifications'),
    commentNotifications: document.getElementById('commentNotifications'),
    systemNotifications: document.getElementById('systemNotifications'),
    theme: document.getElementById('themeSetting'),
    animation: document.getElementById('animationSetting')
};

const defaultSettings = {
    language: 'vi',
    reportNotifications: true,
    commentNotifications: true,
    systemNotifications: false,
    theme: 'light',
    animation: true
};

const settingsMessage = document.getElementById('settingsMessage');
const settingsMessageText = document.getElementById('settingsMessageText');

function getCurrentSettings() {
    return {
        language: settingControls.language.value,
        reportNotifications: settingControls.reportNotifications.checked,
        commentNotifications: settingControls.commentNotifications.checked,
        systemNotifications: settingControls.systemNotifications.checked,
        theme: settingControls.theme.value,
        animation: settingControls.animation.checked
    };
}

function applySettings(settings) {
    settingControls.language.value = settings.language;
    settingControls.reportNotifications.checked = settings.reportNotifications;
    settingControls.commentNotifications.checked = settings.commentNotifications;
    settingControls.systemNotifications.checked = settings.systemNotifications;
    settingControls.theme.value = settings.theme;
    settingControls.animation.checked = settings.animation;
}

function showSettingsMessage(message) {
    settingsMessageText.textContent = message;
    settingsMessage.classList.add('show');
}

function applyVisualSettings() {
    const isDark = settingControls.theme.value === 'dark';

    // Áp dụng chế độ tối cho vùng nội dung trang cài đặt.
    // Sidebar dùng CSS riêng nên không bị thay đổi bởi đoạn này.
    document.querySelector('.settings-page').style.background =
        isDark ? '#111827' : '#f5f7fb';

    document.querySelector('.settings-page').style.color =
        isDark ? '#e5e7eb' : '#1e293b';

    document.querySelectorAll('.settings-card, .settings-nav').forEach(element => {
        element.style.background = isDark ? '#1f2937' : '#ffffff';
        element.style.borderColor = isDark ? '#374151' : '#e9edf5';
    });

    document.querySelectorAll('.settings-card-header, .settings-row').forEach(element => {
        element.style.borderColor = isDark ? '#374151' : '#edf0f6';
    });

    document.querySelectorAll('.settings-row-title, .settings-card-header h3').forEach(element => {
        element.style.color = isDark ? '#f3f4f6' : '#344054';
    });

    document.querySelectorAll('.settings-row-description, .settings-card-header p').forEach(element => {
        element.style.color = isDark ? '#cbd5e1' : '#8994a7';
    });

    document.querySelectorAll('.settings-select').forEach(element => {
        element.style.background = isDark ? '#111827' : '#ffffff';
        element.style.color = isDark ? '#f3f4f6' : '#344054';
        element.style.borderColor = isDark ? '#4b5563' : '#dfe5ef';
    });

    document.querySelectorAll('.settings-nav-title').forEach(element => {
        element.style.color = isDark ? '#9ca3af' : '#98a2b3';
    });

    document.querySelectorAll('.settings-nav-link:not(.active)').forEach(element => {
        element.style.color = isDark ? '#d1d5db' : '#64748b';
    });

    document.querySelectorAll('.settings-card-icon').forEach(element => {
        if (isDark) {
            element.style.filter = 'brightness(.85)';
        } else {
            element.style.filter = '';
        }
    });
}

function loadSettings() {
    try {
        const saved = localStorage.getItem('bugflowUserSettings');

        if (saved) {
            const parsed = JSON.parse(saved);
            applySettings({ ...defaultSettings, ...parsed });
        } else {
            applySettings(defaultSettings);
        }
    } catch (error) {
        applySettings(defaultSettings);
    }

    applyVisualSettings();
}

document.getElementById('saveSettings').addEventListener('click', function () {
    const settings = getCurrentSettings();

    try {
        localStorage.setItem('bugflowUserSettings', JSON.stringify(settings));
        applyVisualSettings();
        showSettingsMessage('Đã lưu cài đặt trên trình duyệt này.');
    } catch (error) {
        showSettingsMessage('Không thể lưu cài đặt trên trình duyệt. Vui lòng kiểm tra chế độ riêng tư hoặc dung lượng lưu trữ.');
    }
});

document.getElementById('resetSettings').addEventListener('click', function () {
    applySettings(defaultSettings);

    try {
        localStorage.removeItem('bugflowUserSettings');
    } catch (error) {
        // Vẫn khôi phục giao diện dù trình duyệt không cho phép lưu trữ.
    }

    applyVisualSettings();
    showSettingsMessage('Đã khôi phục các tùy chọn mặc định.');
});

settingControls.theme.addEventListener('change', applyVisualSettings);

document.getElementById('changePasswordButton').addEventListener('click', function () {
    showSettingsMessage('Chức năng đổi mật khẩu cần được kết nối với backend PHP để xác thực an toàn.');
});

document.querySelectorAll('.settings-nav-link').forEach(link => {
    link.addEventListener('click', function () {
        document.querySelectorAll('.settings-nav-link').forEach(item => {
            item.classList.remove('active');
        });

        this.classList.add('active');
    });
});

loadSettings();
</script>

</body>
</html>

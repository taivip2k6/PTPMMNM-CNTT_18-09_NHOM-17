```php
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$userName = $_SESSION['user_name']
    ?? $_SESSION['username']
    ?? 'Người dùng';

$userInitial = function_exists('mb_substr')
    ? mb_strtoupper(mb_substr($userName, 0, 1, 'UTF-8'), 'UTF-8')
    : strtoupper(substr($userName, 0, 1));

$notifications = [
    [
        'icon' => 'fa-bug',
        'type' => 'blue',
        'title' => 'Báo cáo lỗi đã được tiếp nhận',
        'message' => 'Báo cáo BUG-1024 đã được ghi nhận và đang chờ phân công.',
        'time' => '10 phút trước',
        'date' => 'Hôm nay',
        'unread' => true
    ],
    [
        'icon' => 'fa-user-check',
        'type' => 'green',
        'title' => 'Lỗi đã được phân công',
        'message' => 'Báo cáo BUG-1021 đã được giao cho thành viên phụ trách.',
        'time' => '1 giờ trước',
        'date' => 'Hôm nay',
        'unread' => true
    ],
    [
        'icon' => 'fa-comment-dots',
        'type' => 'purple',
        'title' => 'Có cập nhật mới về báo cáo',
        'message' => 'Báo cáo BUG-1018 vừa có bình luận mới từ đội ngũ phát triển.',
        'time' => '3 giờ trước',
        'date' => 'Hôm nay',
        'unread' => false
    ],
    [
        'icon' => 'fa-circle-check',
        'type' => 'green',
        'title' => 'Báo cáo đã được xử lý',
        'message' => 'Báo cáo BUG-1009 đã được đánh dấu hoàn tất.',
        'time' => 'Hôm qua',
        'date' => 'Hôm qua',
        'unread' => false
    ],
    [
        'icon' => 'fa-clock',
        'type' => 'orange',
        'title' => 'Trạng thái báo cáo đã thay đổi',
        'message' => 'Báo cáo BUG-1006 đang được đội ngũ kỹ thuật xử lý.',
        'time' => '2 ngày trước',
        'date' => 'Trước đó',
        'unread' => false
    ],
];

$unreadCount = count(array_filter(
    $notifications,
    fn($notification) => $notification['unread']
));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông báo | BugFlow</title>

    <link rel="stylesheet" href="/assets/css/user.css">
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>
        .notify-page {
            margin-left: 252px;
            min-height: 100vh;
            padding: 30px;
            background: #f5f7fb;
            color: #1e293b;
            font-family: Inter, Arial, sans-serif;
        }

        .notify-topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 18px;
            margin-bottom: 28px;
        }

        .notify-breadcrumb {
            margin-bottom: 8px;
            color: #8490a5;
            font-size: 13px;
        }

        .notify-topbar h1 {
            margin: 0;
            font-size: 27px;
            font-weight: 750;
        }

        .notify-user {
            display: flex;
            align-items: center;
            gap: 11px;
            padding: 9px 14px;
            background: white;
            border: 1px solid #e8edf5;
            border-radius: 14px;
        }

        .notify-avatar {
            display: grid;
            place-items: center;
            width: 38px;
            height: 38px;
            border-radius: 12px;
            background: #e8edff;
            color: #4f46e5;
            font-weight: 800;
        }

        .notify-user-name {
            font-size: 13px;
            font-weight: 700;
        }

        .notify-user-role {
            margin-top: 3px;
            color: #8994a7;
            font-size: 11px;
        }

        .notify-banner {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            padding: 27px 30px;
            margin-bottom: 24px;
            border-radius: 21px;
            color: white;
            background: linear-gradient(120deg, #4338ca, #6366f1 65%, #818cf8);
        }

        .notify-banner h2 {
            margin: 0 0 9px;
            font-size: 23px;
        }

        .notify-banner p {
            margin: 0;
            color: #e0e7ff;
            font-size: 13px;
            line-height: 1.7;
        }

        .notify-banner-icon {
            display: grid;
            place-items: center;
            width: 70px;
            height: 70px;
            flex-shrink: 0;
            border-radius: 22px;
            background: rgba(255,255,255,.15);
            font-size: 29px;
        }

        .notify-summary {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 17px;
            margin-bottom: 24px;
        }

        .notify-summary-card {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 20px;
            border: 1px solid #e9edf5;
            border-radius: 17px;
            background: white;
        }

        .notify-summary-icon {
            display: grid;
            place-items: center;
            width: 45px;
            height: 45px;
            border-radius: 14px;
            background: #eef2ff;
            color: #4f46e5;
            font-size: 17px;
        }

        .notify-summary-icon.green {
            background: #dcfce7;
            color: #15803d;
        }

        .notify-summary-icon.orange {
            background: #ffedd5;
            color: #c2410c;
        }

        .notify-summary-number {
            font-size: 23px;
            font-weight: 800;
        }

        .notify-summary-label {
            margin-top: 4px;
            color: #8994a7;
            font-size: 12px;
        }

        .notify-panel {
            overflow: hidden;
            border: 1px solid #e9edf5;
            border-radius: 20px;
            background: white;
            box-shadow: 0 8px 30px rgba(30,41,59,.035);
        }

        .notify-panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            padding: 22px 25px;
            border-bottom: 1px solid #edf0f6;
        }

        .notify-panel-header h3 {
            margin: 0 0 6px;
            font-size: 17px;
        }

        .notify-panel-header p {
            margin: 0;
            color: #8994a7;
            font-size: 12px;
        }

        .notify-mark-all {
            padding: 10px 13px;
            border: 1px solid #e0e7ff;
            border-radius: 10px;
            background: #eef2ff;
            color: #4338ca;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
        }

        .notify-mark-all:hover {
            background: #e0e7ff;
        }

        .notify-filters {
            display: flex;
            gap: 8px;
            padding: 16px 25px;
            border-bottom: 1px solid #edf0f6;
        }

        .notify-filter {
            padding: 9px 14px;
            border: 0;
            border-radius: 9px;
            background: transparent;
            color: #7b8799;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
        }

        .notify-filter.active {
            background: #eef2ff;
            color: #4338ca;
        }

        .notify-date-heading {
            padding: 17px 25px 9px;
            color: #98a2b3;
            font-size: 11px;
            font-weight: 800;
            letter-spacing: .8px;
            text-transform: uppercase;
        }

        .notify-item {
            display: flex;
            align-items: flex-start;
            gap: 15px;
            padding: 19px 25px;
            border-bottom: 1px solid #f0f2f7;
            transition: background .2s;
        }

        .notify-item:hover {
            background: #fafbff;
        }

        .notify-item.unread {
            background: #f8faff;
        }

        .notify-item.unread:hover {
            background: #f1f5ff;
        }

        .notify-item[hidden] {
            display: none;
        }

        .notify-icon {
            display: grid;
            place-items: center;
            width: 44px;
            height: 44px;
            flex-shrink: 0;
            border-radius: 14px;
            font-size: 16px;
        }

        .notify-icon.blue {
            color: #4f46e5;
            background: #eef2ff;
        }

        .notify-icon.green {
            color: #15803d;
            background: #dcfce7;
        }

        .notify-icon.purple {
            color: #7e22ce;
            background: #f3e8ff;
        }

        .notify-icon.orange {
            color: #c2410c;
            background: #ffedd5;
        }

        .notify-content {
            flex: 1;
            min-width: 0;
        }

        .notify-item-title {
            margin: 2px 0 7px;
            font-size: 13px;
            font-weight: 750;
        }

        .notify-item-message {
            margin: 0;
            color: #7b8799;
            font-size: 12px;
            line-height: 1.7;
        }

        .notify-item-time {
            margin-top: 9px;
            color: #98a2b3;
            font-size: 11px;
        }

        .notify-unread-dot {
            width: 8px;
            height: 8px;
            flex-shrink: 0;
            margin-top: 7px;
            border-radius: 50%;
            background: #6366f1;
        }

        .notify-item:not(.unread) .notify-unread-dot {
            visibility: hidden;
        }

        .notify-empty {
            display: none;
            padding: 45px 20px;
            color: #98a2b3;
            text-align: center;
            font-size: 13px;
        }

        .notify-empty i {
            display: block;
            margin-bottom: 12px;
            font-size: 30px;
        }

        @media (max-width: 1000px) {
            .notify-summary {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .notify-page {
                margin-left: 0;
                padding: 20px 14px;
            }

            .notify-topbar h1 {
                font-size: 22px;
            }

            .notify-user {
                padding: 7px;
            }

            .notify-user-info {
                display: none;
            }

            .notify-banner {
                padding: 22px;
            }

            .notify-banner h2 {
                font-size: 19px;
            }

            .notify-banner-icon {
                width: 52px;
                height: 52px;
                font-size: 23px;
            }

            .notify-panel-header,
            .notify-item {
                padding-left: 16px;
                padding-right: 16px;
            }

            .notify-filters {
                padding: 13px 12px;
                overflow-x: auto;
            }

            .notify-filter {
                white-space: nowrap;
            }

            .notify-date-heading {
                padding-left: 16px;
            }

            .notify-icon {
                width: 38px;
                height: 38px;
            }
        }
    </style>
</head>
<body>

<?php require __DIR__ . '/sidebar.php'; ?>

<main class="notify-page">
    <header class="notify-topbar">
        <div>
            <div class="notify-breadcrumb">
                <i class="fa-solid fa-house"></i>
                &nbsp; Trang người dùng / Thông báo
            </div>
            <h1>Thông báo</h1>
        </div>

        <div class="notify-user">
            <div class="notify-avatar">
                <?= htmlspecialchars($userInitial, ENT_QUOTES, 'UTF-8') ?>
            </div>
            <div class="notify-user-info">
                <div class="notify-user-name">
                    <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?>
                </div>
                <div class="notify-user-role">Người báo cáo</div>
            </div>
        </div>
    </header>

    <section class="notify-banner">
        <div>
            <h2><i class="fa-regular fa-bell"></i> Trung tâm thông báo</h2>
            <p>Theo dõi các cập nhật mới nhất về báo cáo lỗi của bạn.</p>
        </div>
        <div class="notify-banner-icon">
            <i class="fa-solid fa-bell"></i>
        </div>
    </section>

    <section class="notify-summary">
        <div class="notify-summary-card">
            <div class="notify-summary-icon">
                <i class="fa-regular fa-bell"></i>
            </div>
            <div>
                <div class="notify-summary-number" id="totalCount">
                    <?= count($notifications) ?>
                </div>
                <div class="notify-summary-label">Tổng thông báo mẫu</div>
            </div>
        </div>

        <div class="notify-summary-card">
            <div class="notify-summary-icon orange">
                <i class="fa-solid fa-envelope"></i>
            </div>
            <div>
                <div class="notify-summary-number" id="unreadCount">
                    <?= $unreadCount ?>
                </div>
                <div class="notify-summary-label">Chưa đọc</div>
            </div>
        </div>

        <div class="notify-summary-card">
            <div class="notify-summary-icon green">
                <i class="fa-solid fa-check-double"></i>
            </div>
            <div>
                <div class="notify-summary-number" id="readCount">
                    <?= count($notifications) - $unreadCount ?>
                </div>
                <div class="notify-summary-label">Đã đọc</div>
            </div>
        </div>
    </section>

    <section class="notify-panel">
        <div class="notify-panel-header">
            <div>
                <h3>Danh sách thông báo</h3>
                <p>Các cập nhật liên quan đến hoạt động báo cáo lỗi.</p>
            </div>

            <button type="button" class="notify-mark-all" id="markAll">
                <i class="fa-solid fa-check-double"></i>
                Đánh dấu đã đọc
            </button>
        </div>

        <div class="notify-filters">
            <button type="button" class="notify-filter active" data-filter="all">
                Tất cả
            </button>
            <button type="button" class="notify-filter" data-filter="unread">
                Chưa đọc
            </button>
            <button type="button" class="notify-filter" data-filter="read">
                Đã đọc
            </button>
        </div>

        <?php
        $lastDate = null;

        foreach ($notifications as $index => $notification):
            if ($lastDate !== $notification['date']):
                $lastDate = $notification['date'];
        ?>
            <div class="notify-date-heading">
                <?= htmlspecialchars($lastDate, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php
            endif;
        ?>

            <article
                class="notify-item <?= $notification['unread'] ? 'unread' : '' ?>"
                data-status="<?= $notification['unread'] ? 'unread' : 'read' ?>"
            >
                <div class="notify-icon <?= htmlspecialchars($notification['type'], ENT_QUOTES, 'UTF-8') ?>">
                    <i class="fa-solid <?= htmlspecialchars($notification['icon'], ENT_QUOTES, 'UTF-8') ?>"></i>
                </div>

                <div class="notify-content">
                    <h4 class="notify-item-title">
                        <?= htmlspecialchars($notification['title'], ENT_QUOTES, 'UTF-8') ?>
                    </h4>

                    <p class="notify-item-message">
                        <?= htmlspecialchars($notification['message'], ENT_QUOTES, 'UTF-8') ?>
                    </p>

                    <div class="notify-item-time">
                        <i class="fa-regular fa-clock"></i>
                        <?= htmlspecialchars($notification['time'], ENT_QUOTES, 'UTF-8') ?>
                    </div>
                </div>

                <span class="notify-unread-dot" title="Chưa đọc"></span>
            </article>

        <?php endforeach; ?>

        <div class="notify-empty" id="notifyEmpty">
            <i class="fa-regular fa-bell-slash"></i>
            Không có thông báo trong mục này.
        </div>
    </section>
</main>

<script>
const notificationItems = [
    ...document.querySelectorAll('.notify-item')
];

const filterButtons = [
    ...document.querySelectorAll('.notify-filter')
];

const unreadCountElement = document.getElementById('unreadCount');
const readCountElement = document.getElementById('readCount');
const emptyElement = document.getElementById('notifyEmpty');

let currentFilter = 'all';

function updateNotificationCounts() {
    const unread = notificationItems.filter(
        item => item.dataset.status === 'unread'
    ).length;

    unreadCountElement.textContent = unread;
    readCountElement.textContent = notificationItems.length - unread;
}

function applyNotificationFilter() {
    let visibleCount = 0;

    notificationItems.forEach(item => {
        const matches =
            currentFilter === 'all' ||
            item.dataset.status === currentFilter;

        item.hidden = !matches;

        if (matches) {
            visibleCount++;
        }
    });

    emptyElement.style.display = visibleCount === 0 ? 'block' : 'none';

    // Ẩn tiêu đề ngày nếu bên dưới không còn thông báo nào hiển thị.
    document.querySelectorAll('.notify-date-heading').forEach(heading => {
        let next = heading.nextElementSibling;
        let hasVisibleNotification = false;

        while (next && !next.classList.contains('notify-date-heading')) {
            if (
                next.classList.contains('notify-item') &&
                !next.hidden
            ) {
                hasVisibleNotification = true;
                break;
            }

            next = next.nextElementSibling;
        }

        heading.hidden = !hasVisibleNotification;
    });
}

filterButtons.forEach(button => {
    button.addEventListener('click', function () {
        currentFilter = this.dataset.filter;

        filterButtons.forEach(item => item.classList.remove('active'));
        this.classList.add('active');

        applyNotificationFilter();
    });
});

notificationItems.forEach(item => {
    item.addEventListener('click', function () {
        if (this.dataset.status === 'unread') {
            this.dataset.status = 'read';
            this.classList.remove('unread');

            updateNotificationCounts();
            applyNotificationFilter();
        }
    });
});

document.getElementById('markAll').addEventListener('click', function () {
    notificationItems.forEach(item => {
        item.dataset.status = 'read';
        item.classList.remove('unread');
    });

    updateNotificationCounts();
    applyNotificationFilter();
});

updateNotificationCounts();
applyNotificationFilter();
</script>

</body>
</html>

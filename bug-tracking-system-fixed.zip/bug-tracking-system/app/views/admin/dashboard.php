
<?php
// ADMIN DASHBOARD - DEMO DATA
// Sau này sẽ lấy dữ liệu từ MySQL.

$totalBugs = 128;
$openBugs = 42;
$progressBugs = 36;
$resolvedBugs = 50;

$totalProjects = 8;
$totalUsers = 24;
$activeReleases = 3;

$recentBugs = [
    [
        'id' => 'BUG-1024',
        'title' => 'Login authentication failed',
        'project' => 'Website Application',
        'priority' => 'Critical',
        'status' => 'Open',
        'assignee' => 'Nguyen Van A'
    ],
    [
        'id' => 'BUG-1023',
        'title' => 'Dashboard responsive issue',
        'project' => 'Mobile Application',
        'priority' => 'High',
        'status' => 'In Progress',
        'assignee' => 'Tran Thi B'
    ],
    [
        'id' => 'BUG-1022',
        'title' => 'API timeout on checkout',
        'project' => 'Backend API',
        'priority' => 'High',
        'status' => 'Open',
        'assignee' => 'Le Van C'
    ],
    [
        'id' => 'BUG-1021',
        'title' => 'Incorrect profile validation',
        'project' => 'Website Application',
        'priority' => 'Medium',
        'status' => 'Resolved',
        'assignee' => 'Pham Van D'
    ]
];

$releases = [
    [
        'name' => 'Website v2.1',
        'date' => '2026-11-10',
        'progress' => 75
    ],
    [
        'name' => 'Mobile App v1.5',
        'date' => '2026-11-18',
        'progress' => 45
    ],
    [
        'name' => 'Backend API v3.0',
        'date' => '2026-12-01',
        'progress' => 85
    ]
];

function adminEscape($value) {
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function adminPriorityClass($priority) {
    return match ($priority) {
        'Low' => 'priority-low',
        'Medium' => 'priority-medium',
        'High' => 'priority-high',
        'Critical' => 'priority-critical',
        default => ''
    };
}

function adminStatusClass($status) {
    return match ($status) {
        'Open' => 'status-open',
        'In Progress' => 'status-progress',
        'Resolved' => 'status-resolved',
        'Closed' => 'status-closed',
        default => ''
    };
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard | BugFlow</title>

    <!-- CSS CHUNG -->
    <link rel="stylesheet" href="/assets/css/style.css">

    <!-- CSS ADMIN -->
    <link rel="stylesheet" href="/assets/css/dashboard.css">

    <!-- FONT AWESOME -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

<div class="app-layout">

    <!-- ADMIN SIDEBAR -->
    <aside class="sidebar">

        <a href="/?page=admin-dashboard" class="brand">
            <div class="brand-icon">
                <i class="fa-solid fa-bug"></i>
            </div>
            Bug<span>Flow</span>
        </a>

        <div class="menu-label">ADMIN WORKSPACE</div>

        <nav class="nav-menu">

            <a href="/?page=admin-dashboard"
               class="nav-link active">
                <i class="fa-solid fa-chart-pie"></i>
                Dashboard
            </a>

            <a href="/?page=admin-bugs"
               class="nav-link">
                <i class="fa-solid fa-bug"></i>
                Bug Management
            </a>

            <a href="/?page=admin-projects"
               class="nav-link">
                <i class="fa-solid fa-folder-open"></i>
                Projects
            </a>

            <a href="/?page=admin-releases"
               class="nav-link">
                <i class="fa-solid fa-rocket"></i>
                Releases
            </a>

            <a href="/?page=admin-users"
               class="nav-link">
                <i class="fa-solid fa-users"></i>
                User Management
            </a>

        </nav>

        <div class="menu-label">SYSTEM</div>

        <nav class="nav-menu">

            <a href="/?page=admin-settings"
               class="nav-link">
                <i class="fa-solid fa-gear"></i>
                Settings
            </a>

            <a href="/?page=bugs"
               class="nav-link">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                Back to User
            </a>

        </nav>

        <div class="sidebar-bottom">

            <div class="user-profile">
                <div class="avatar">AD</div>

                <div class="user-info">
                    <strong>Administrator</strong>
                    <small>System Admin</small>
                </div>
            </div>

        </div>

    </aside>

    <!-- MAIN -->
    <main class="main-content">

        <!-- TOPBAR -->
        <header class="topbar">

            <div class="search-box">
                <i class="fa-solid fa-magnifying-glass"></i>

                <input type="search"
                       placeholder="Search system...">
            </div>

            <div class="topbar-actions">

                <button class="icon-button"
                        type="button"
                        aria-label="Notifications">
                    <i class="fa-regular fa-bell"></i>
                </button>

                <div class="avatar">AD</div>

            </div>

        </header>

        <!-- DASHBOARD CONTENT -->
        <div class="page-content">

            <div class="page-header">

                <div>
                    <h1 class="page-title">
                        Dashboard Overview
                    </h1>

                    <p class="page-subtitle">
                        Welcome back, Administrator!
                        Here's what's happening across your projects.
                    </p>
                </div>

                <div class="dashboard-date">
                    <i class="fa-regular fa-calendar"></i>
                    <?= date('d M Y') ?>
                </div>

            </div>

            <!-- STATS -->
            <div class="stats-grid">

                <div class="stat-card">
                    <div class="stat-icon purple">
                        <i class="fa-solid fa-bug"></i>
                    </div>

                    <div class="stat-label">
                        Total Bugs
                    </div>

                    <div class="stat-number">
                        <?= $totalBugs ?>
                    </div>

                    <div class="stat-footer">
                        Across all projects
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon red">
                        <i class="fa-solid fa-circle-exclamation"></i>
                    </div>

                    <div class="stat-label">
                        Open Bugs
                    </div>

                    <div class="stat-number">
                        <?= $openBugs ?>
                    </div>

                    <div class="stat-footer">
                        Require attention
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon orange">
                        <i class="fa-solid fa-spinner"></i>
                    </div>

                    <div class="stat-label">
                        In Progress
                    </div>

                    <div class="stat-number">
                        <?= $progressBugs ?>
                    </div>

                    <div class="stat-footer">
                        Currently being fixed
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon green">
                        <i class="fa-solid fa-circle-check"></i>
                    </div>

                    <div class="stat-label">
                        Resolved Bugs
                    </div>

                    <div class="stat-number">
                        <?= $resolvedBugs ?>
                    </div>

                    <div class="stat-footer">
                        Successfully resolved
                    </div>
                </div>

            </div>

            <!-- CHARTS -->
            <div class="dashboard-grid">

                <section class="card">
                    <div class="section-heading">
                        <div>
                            <h2 class="card-title">
                                Bug Activity
                            </h2>

                            <p class="section-subtitle">
                                Monthly reported and resolved bugs
                            </p>
                        </div>
                    </div>

                    <div class="chart-container">
                        <canvas id="bugActivityChart"></canvas>
                    </div>
                </section>

                <section class="card">
                    <div class="section-heading">
                        <div>
                            <h2 class="card-title">
                                Bug Distribution
                            </h2>

                            <p class="section-subtitle">
                                Current issue status
                            </p>
                        </div>
                    </div>

                    <div class="chart-container">
                        <canvas id="bugStatusChart"></canvas>
                    </div>
                </section>

            </div>

            <!-- OVERVIEW -->
            <div class="overview-grid">

                <div class="overview-item">
                    <div class="overview-icon purple">
                        <i class="fa-solid fa-folder-open"></i>
                    </div>

                    <div>
                        <strong><?= $totalProjects ?></strong>
                        <span>Active Projects</span>
                    </div>
                </div>

                <div class="overview-item">
                    <div class="overview-icon green">
                        <i class="fa-solid fa-users"></i>
                    </div>

                    <div>
                        <strong><?= $totalUsers ?></strong>
                        <span>Team Members</span>
                    </div>
                </div>

                <div class="overview-item">
                    <div class="overview-icon orange">
                        <i class="fa-solid fa-rocket"></i>
                    </div>

                    <div>
                        <strong><?= $activeReleases ?></strong>
                        <span>Active Releases</span>
                    </div>
                </div>

            </div>

            <!-- RECENT BUGS -->
            <section class="card">

                <div class="section-heading">
                    <div>
                        <h2 class="card-title">Recent Bugs</h2>

                        <p class="section-subtitle">
                            Latest reported issues across projects
                        </p>
                    </div>

                    <a href="/?page=admin-bugs"
                       class="btn btn-secondary">
                        View All
                        <i class="fa-solid fa-arrow-right"></i>
                    </a>
                </div>

                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Bug ID</th>
                                <th>Bug Details</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th>Assigned To</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php foreach ($recentBugs as $bug): ?>
                            <tr>
                                <td class="bug-id">
                                    <?= adminEscape($bug['id']) ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= adminEscape($bug['title']) ?>
                                    </strong>

                                    <div class="bug-project">
                                        <?= adminEscape($bug['project']) ?>
                                    </div>
                                </td>

                                <td>
                                    <span class="priority <?= adminPriorityClass($bug['priority']) ?>">
                                        <?= adminEscape($bug['priority']) ?>
                                    </span>
                                </td>

                                <td>
                                    <span class="status-badge <?= adminStatusClass($bug['status']) ?>">
                                        <?= adminEscape($bug['status']) ?>
                                    </span>
                                </td>

                                <td>
                                    <?= adminEscape($bug['assignee']) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            </section>

            <!-- RELEASE PROGRESS -->
            <section class="card">

                <div class="section-heading">
                    <div>
                        <h2 class="card-title">
                            Release Progress
                        </h2>

                        <p class="section-subtitle">
                            Upcoming software releases
                        </p>
                    </div>

                    <a href="/?page=admin-releases"
                       class="btn btn-secondary">
                        View Releases
                    </a>
                </div>

                <div class="release-list">

                    <?php foreach ($releases as $release): ?>

                        <div class="release-item">

                            <div class="release-heading">
                                <strong>
                                    <?= adminEscape($release['name']) ?>
                                </strong>

                                <span>
                                    <?= (int) $release['progress'] ?>%
                                </span>
                            </div>

                            <div class="progress-track">
                                <div class="progress-fill"
                                     style="width: <?= (int) $release['progress'] ?>%">
                                </div>
                            </div>

                            <small>
                                Target:
                                <?= adminEscape($release['date']) ?>
                            </small>

                        </div>

                    <?php endforeach; ?>

                </div>

            </section>

        </div>
    </main>
</div>

<!-- CHART LIBRARY -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- ADMIN JAVASCRIPT -->
<script src="/assets/js/admin/dashboard.js"></script>

</body>
</html>

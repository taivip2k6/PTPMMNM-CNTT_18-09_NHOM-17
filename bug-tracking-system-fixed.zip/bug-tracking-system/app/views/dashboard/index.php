<?php require '../app/views/layouts/header.php'; ?>

<div class="container-fluid">

    <div class="row">

        <div class="col-md-2">
            <?php require '../app/views/layouts/user_sidebar.php'; ?>
        </div>

        <div class="col-md-10 p-4">

            <h2>Welcome Back</h2>

            <div class="row mt-4">

                <div class="col-md-4">

                    <div class="card bg-primary text-white">

                        <div class="card-body">

                            <h5>Assigned Bugs</h5>

                            <h2>10</h2>

                        </div>

                    </div>

                </div>

                <div class="col-md-4">

                    <div class="card bg-warning">

                        <div class="card-body">

                            <h5>In Progress</h5>

                            <h2>4</h2>

                        </div>

                    </div>

                </div>

                <div class="col-md-4">

                    <div class="card bg-success text-white">

                        <div class="card-body">

                            <h5>Resolved</h5>

                            <h2>6</h2>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

</body>
</html>
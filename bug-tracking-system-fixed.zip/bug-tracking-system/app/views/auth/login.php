<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

<h2>Bug Tracking System</h2>

<form method="POST">

    <input
        type="email"
        name="email"
        placeholder="Email"
        required
    >

    <br><br>

    <input
        type="password"
        name="password"
        placeholder="Password"
        required
    >

    <br><br>

    <button type="submit">
        Login
    </button>

</form>

</body>
</html>

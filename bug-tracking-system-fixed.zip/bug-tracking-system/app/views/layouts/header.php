<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bug Tracking System</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="bg-dark text-white p-3 vh-100">

    <h4>Bug Tracker</h4>

    <hr>

    <ul class="nav flex-column">

        <li class="nav-item mb-2">
            <a href="#" class="nav-link text-white">
                Dashboard
            </a>
        </li>

        <li class="nav-item mb-2">
            <a href="#" class="nav-link text-white">
                My Bugs
            </a>
        </li>

        <li class="nav-item mb-2">
            <a href="#" class="nav-link text-white">
                Report Bug
            </a>
        </li>

        <li class="nav-item mb-2">
            <a href="#" class="nav-link text-white">
                Notifications
            </a>
        </li>

        <li class="nav-item mb-2">
            <a href="#" class="nav-link text-white">
                Profile
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link text-danger">
                Logout
            </a>
        </li>

    </ul>

</div>
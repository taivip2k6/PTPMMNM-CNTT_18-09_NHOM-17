<?php

require_once __DIR__ . '/../models/User.php';

class AuthController
{
    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $email = $_POST['email'];
            $password = $_POST['password'];

            $userModel = new User();

            $user = $userModel->findByEmail($email);

            if ($user && $user['password'] == $password) {

                session_start();

                $_SESSION['user'] = $user;

                echo "Đăng nhập thành công";
            } else {

                echo "Sai email hoặc mật khẩu";
            }
        }
    }
}
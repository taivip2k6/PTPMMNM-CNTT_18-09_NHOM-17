
/* ==========================================
   BUGFLOW - USER DASHBOARD JAVASCRIPT
   ========================================== */

document.addEventListener('DOMContentLoaded', function () {

    // =====================================
    // 1. BUG ACTIVITY CHART
    // =====================================

    const chartCanvas = document.getElementById(
        'userBugActivityChart'
    );

    if (chartCanvas && typeof Chart !== 'undefined') {

        Chart.defaults.font.family = 'Inter, sans-serif';
        Chart.defaults.color = '#8991a5';

        const ctx = chartCanvas.getContext('2d');

        // Gradient background
        const gradient = ctx.createLinearGradient(
            0, 0, 0, 300
        );

        gradient.addColorStop(
            0, 'rgba(99, 91, 255, 0.20)'
        );

        gradient.addColorStop(
            1, 'rgba(99, 91, 255, 0.01)'
        );

        new Chart(ctx, {
            type: 'line',

            data: {
                labels: [
                    'May', 'Jun', 'Jul',
                    'Aug', 'Sep', 'Oct'
                ],

                datasets: [
                    {
                        label: 'Reported Bugs',
                        data: [3, 5, 4, 8, 6, 10],
                        borderColor: '#635bff',
                        backgroundColor: gradient,
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        pointBackgroundColor: '#635bff',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2
                    },
                    {
                        label: 'Resolved Bugs',
                        data: [1, 3, 3, 5, 4, 7],
                        borderColor: '#16a878',
                        backgroundColor: 'transparent',
                        borderWidth: 3,
                        fill: false,
                        tension: 0.4,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        pointBackgroundColor: '#16a878',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2
                    }
                ]
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,

                interaction: {
                    mode: 'index',
                    intersect: false
                },

                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            boxWidth: 8
                        }
                    },

                    tooltip: {
                        backgroundColor: '#252a41',
                        padding: 12,
                        cornerRadius: 9
                    }
                },

                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        border: {
                            display: false
                        }
                    },

                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            stepSize: 2
                        },
                        grid: {
                            color: '#edf0f7'
                        },
                        border: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    // =====================================
    // 2. SEARCH RECENT BUGS
    // =====================================

    const searchInput = document.getElementById(
        'dashboardSearch'
    );

    const bugRows = Array.from(
        document.querySelectorAll(
            '#recentBugsTable tbody tr'
        )
    );

    const emptyState = document.getElementById(
        'dashboardEmpty'
    );

    function searchBugs() {

        if (!searchInput) return;

        const keyword = searchInput.value
            .trim()
            .toLowerCase();

        let visibleCount = 0;

        bugRows.forEach(function (row) {

            const rowText = row.textContent.toLowerCase();

            const isMatch = rowText.includes(keyword);

            row.style.display = isMatch ? '' : 'none';

            if (isMatch) {
                visibleCount++;
            }
        });

        if (emptyState) {
            emptyState.style.display =
                visibleCount === 0 ? 'block' : 'none';
        }
    }

    if (searchInput) {
        searchInput.addEventListener(
            'input',
            searchBugs
        );
    }

    // =====================================
    // 3. NOTIFICATION BUTTON (DEMO)
    // =====================================

    const notificationButton = document.querySelector(
        '.topbar-actions .icon-button'
    );

    if (notificationButton) {
        notificationButton.addEventListener(
            'click',
            function () {
                alert('You have no new notifications.');
            }
        );
    }

});

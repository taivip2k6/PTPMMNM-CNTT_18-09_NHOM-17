
/* ======================================
   BUGFLOW - ADMIN DASHBOARD CHARTS
   ====================================== */

document.addEventListener('DOMContentLoaded', function () {

    if (typeof Chart === 'undefined') {
        console.error('Chart.js has not loaded.');
        return;
    }

    // Global chart settings
    Chart.defaults.font.family = 'Inter, sans-serif';
    Chart.defaults.color = '#8991a5';

    // ==================================
    // CHART 1: MONTHLY BUG ACTIVITY
    // ==================================

    const activityCanvas =
        document.getElementById('bugActivityChart');

    if (activityCanvas) {

        const activityContext =
            activityCanvas.getContext('2d');

        const gradient =
            activityContext.createLinearGradient(
                0, 0, 0, 300
            );

        gradient.addColorStop(
            0, 'rgba(99, 91, 255, 0.22)'
        );

        gradient.addColorStop(
            1, 'rgba(99, 91, 255, 0.01)'
        );

        new Chart(activityCanvas, {
            type: 'line',

            data: {
                labels: [
                    'May', 'Jun', 'Jul',
                    'Aug', 'Sep', 'Oct'
                ],

                datasets: [
                    {
                        label: 'Reported Bugs',
                        data: [18, 25, 21, 36, 30, 42],
                        borderColor: '#635bff',
                        backgroundColor: gradient,
                        borderWidth: 3,
                        tension: 0.4,
                        fill: true,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        pointBackgroundColor: '#635bff',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2
                    },
                    {
                        label: 'Resolved Bugs',
                        data: [12, 18, 19, 25, 27, 35],
                        borderColor: '#16a878',
                        backgroundColor: 'transparent',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: false,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        pointBackgroundColor: '#16a878',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2
                    }
                ]
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,

                interaction: {
                    mode: 'index',
                    intersect: false
                },

                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            boxWidth: 8
                        }
                    },

                    tooltip: {
                        backgroundColor: '#20243a',
                        padding: 12,
                        cornerRadius: 9
                    }
                },

                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        border: {
                            display: false
                        }
                    },

                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            stepSize: 10
                        },
                        grid: {
                            color: '#edf0f7'
                        },
                        border: {
                            display: false,
                            dash: [4, 4]
                        }
                    }
                }
            }
        });
    }

    // ==================================
    // CHART 2: BUG STATUS DISTRIBUTION
    // ==================================

    const statusCanvas =
        document.getElementById('bugStatusChart');

    if (statusCanvas) {

        new Chart(statusCanvas, {
            type: 'doughnut',

            data: {
                labels: [
                    'Open',
                    'In Progress',
                    'Resolved'
                ],

                datasets: [{
                    data: [42, 36, 50],

                    backgroundColor: [
                        '#ef5b67',
                        '#f3a536',
                        '#16a878'
                    ],

                    borderColor: '#ffffff',
                    borderWidth: 5,
                    hoverOffset: 8,
                    borderRadius: 5
                }]
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '72%',

                plugins: {
                    legend: {
                        position: 'bottom',

                        labels: {
                            usePointStyle: true,
                            padding: 18,
                            boxWidth: 9,
                            font: {
                                size: 12
                            }
                        }
                    },

                    tooltip: {
                        backgroundColor: '#20243a',
                        padding: 12,
                        cornerRadius: 9
                    }
                }
            }
        });
    }

});


<?php

$page = $_GET['page'] ?? 'user-dashboard';

switch ($page) {

    // USER DASHBOARD
    case 'user-dashboard':
        require_once __DIR__ . '/../app/views/users/dashboard.php';
        break;

    // USER - MY BUGS
    case 'bugs':
        require_once __DIR__ . '/../app/views/users/index.php';
        break;

    // USER - REPORT NEW BUG
    case 'create':
        require_once __DIR__ . '/../app/views/users/create.php';
        break;

    // ADMIN DASHBOARD
    case 'admin-dashboard':
        require_once __DIR__ . '/../app/views/admin/dashboard.php';
        break;
    case 'profile':
    require_once __DIR__ . '/../app/views/users/profile.php';
    break;

case 'notifications':
    require_once __DIR__ . '/../app/views/users/notifications.php';
    break;

case 'settings':
    require_once __DIR__ . '/../app/views/users/settings.php';
    break;

    // DEFAULT
    default:
        require_once __DIR__ . '/../app/views/users/dashboard.php';
        break;
}

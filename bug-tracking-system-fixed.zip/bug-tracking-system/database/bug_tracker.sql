CREATE DATABASE IF NOT EXISTS bug_tracker
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE bug_tracker;

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'developer', 'tester')
        NOT NULL DEFAULT 'tester',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS bugs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    priority ENUM('low', 'medium', 'high', 'critical')
        NOT NULL DEFAULT 'medium',
    status ENUM('open', 'in_progress', 'resolved', 'closed')
        NOT NULL DEFAULT 'open',
    reporter_id INT UNSIGNED NOT NULL,
    assigned_to INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_bugs_reporter
        FOREIGN KEY (reporter_id) REFERENCES users(id)
        ON DELETE RESTRICT,

    CONSTRAINT fk_bugs_assignee
        FOREIGN KEY (assigned_to) REFERENCES users(id)
        ON DELETE SET NULL,

    INDEX idx_bugs_status (status),
    INDEX idx_bugs_priority (priority),
    INDEX idx_bugs_created_at (created_at)
) ENGINE=InnoDB;
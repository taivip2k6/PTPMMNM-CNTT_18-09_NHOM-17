<?php

class Database
{
    private $host = "127.0.0.1";
    private $port = "3307";
    private $dbname = "bug_tracker";
    private $username = "root";
    private $password = "";

    public function connect(): PDO
    {
        try {
            $pdo = new PDO(
                "mysql:host={$this->host};port={$this->port};dbname={$this->dbname};charset=utf8",
                $this->username,
                $this->password
            );

            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            return $pdo;

        } catch (PDOException $e) {
            die("Database Error: " . $e->getMessage());
        }
    }
}
